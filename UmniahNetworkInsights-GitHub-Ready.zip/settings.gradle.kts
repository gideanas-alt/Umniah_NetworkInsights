pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "UmniahNetworkInsights"
include(":app")
include(":core:model")
include(":core:designsystem")
include(":core:data")
include(":domain")
include(":telemetry")

package com.umniah.networkinsights.telemetry

import android.os.SystemClock
import com.umniah.networkinsights.core.model.Availability
import com.umniah.networkinsights.core.model.CollectionTrigger
import com.umniah.networkinsights.core.model.ConsentType
import com.umniah.networkinsights.core.model.DiagnosticClassification
import com.umniah.networkinsights.core.model.DiagnosticResult
import com.umniah.networkinsights.core.model.ExperienceSummary
import com.umniah.networkinsights.core.model.LiveNetworkState
import com.umniah.networkinsights.core.model.MeasurementQuality
import com.umniah.networkinsights.core.model.MeasurementType
import com.umniah.networkinsights.core.model.NetworkTechnology
import com.umniah.networkinsights.core.model.TelemetryEnvelope
import com.umniah.networkinsights.core.model.TransportType
import com.umniah.networkinsights.domain.ConsentRepository
import com.umniah.networkinsights.domain.DiagnosticEngine
import com.umniah.networkinsights.domain.EventDetector
import com.umniah.networkinsights.domain.ExperienceScorer
import com.umniah.networkinsights.domain.InstallationRepository
import com.umniah.networkinsights.domain.MobilityClassifier
import com.umniah.networkinsights.domain.PolicyRepository
import com.umniah.networkinsights.domain.TelemetryRepository
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

@Singleton
class TelemetryEngine @Inject constructor(
    private val deviceCollector: DeviceCollector,
    private val subscriptionCollector: SubscriptionCollector,
    private val radioCollector: RadioCollector,
    private val connectivityCollector: ConnectivityCollector,
    private val wifiCollector: WifiCollector,
    private val imsCollector: ImsCollector,
    private val locationCollector: LocationCollector,
    private val performanceEngine: PerformanceEngine,
    private val consentRepository: ConsentRepository,
    private val policyRepository: PolicyRepository,
    private val installationRepository: InstallationRepository,
    private val telemetryRepository: TelemetryRepository
) {
    private val scorer = ExperienceScorer()
    private val detector = EventDetector()
    private val diagnosticEngine = DiagnosticEngine()
    private val mobilityClassifier = MobilityClassifier()
    private val _state = MutableStateFlow(LiveNetworkState())
    val state: StateFlow<LiveNetworkState> = _state.asStateFlow()

    suspend fun refresh(trigger: CollectionTrigger = CollectionTrigger.PERIODIC): LiveNetworkState {
        if (!consentRepository.isEnabled(ConsentType.NETWORK_MEASUREMENTS)) return _state.value

        val now = System.currentTimeMillis()
        val policy = policyRepository.current()
        val connectivity = connectivityCollector.collect()
        val radio = radioCollector.collect()
        val wifi = if (policy.wifiMeasurements) wifiCollector.collect() else null
        val ims = imsCollector.collect()
        val servingCell = radio.cells.firstOrNull { it.registered } ?: radio.cells.firstOrNull()
        val isWifi = connectivity.transport == TransportType.WIFI
        val signalLevel = if (isWifi) wifi?.rssiDbm?.let(::wifiLevel) else radio.signalLevel

        val base = LiveNetworkState(
            collectedAtMs = now,
            technology = if (isWifi) NetworkTechnology.WIFI else radio.technology,
            architecture5g = radio.architecture5g,
            operatorName = radio.operatorName,
            connected = connectivity.transport != TransportType.NONE,
            internetValidated = connectivity.validated,
            transport = connectivity.transport,
            signalLevel = signalLevel,
            rsrpDbm = if (isWifi) null else servingCell?.rsrpDbm,
            rsrqDb = if (isWifi) null else servingCell?.rsrqDb,
            sinrDb = if (isWifi) null else servingCell?.sinrDb,
            cell = if (isWifi) null else servingCell,
            latencyMs = _state.value.latencyMs,
            downloadMbps = _state.value.downloadMbps,
            uploadMbps = _state.value.uploadMbps,
            imsRegistered = ims.registered,
            imsTransport = ims.registrationTransport,
            volteAvailable = ims.volteAvailable,
            vowifiAvailable = ims.vowifiAvailable,
            experience = ExperienceSummary.unavailable(),
            lastEvents = _state.value.lastEvents
        )
        val events = detector.detect(_state.value.takeIf { it.collectedAtMs > 0 }, base)
        val withEvents = base.copy(lastEvents = (events + _state.value.lastEvents).take(20))
        val finalState = withEvents.copy(experience = scorer.score(withEvents))
        _state.value = finalState

        val device = if (consentRepository.isEnabled(ConsentType.DEVICE_INFORMATION)) deviceCollector.collect() else null
        val subscriptions = subscriptionCollector.collect()
        val precise = consentRepository.isEnabled(ConsentType.PRECISE_LOCATION)
        val approximate = consentRepository.isEnabled(ConsentType.APPROXIMATE_LOCATION) || precise
        val location = if (policy.enableLocation && approximate) locationCollector.collect(precise, approximate) else null
        val mobility = mobilityClassifier.classify(location?.speedMps, location?.accuracyM)

        telemetryRepository.enqueue(
            TelemetryEnvelope(
                eventId = UUID.randomUUID().toString(),
                installationId = installationRepository.installationId(),
                sequenceNumber = installationRepository.nextSequence(),
                timestampMs = now,
                elapsedRealtimeMs = SystemClock.elapsedRealtime(),
                measurementType = MeasurementType.RADIO,
                trigger = trigger,
                device = device,
                subscriptions = subscriptions,
                radio = radio,
                connectivity = connectivity,
                wifi = wifi,
                ims = ims,
                location = location,
                mobilityState = mobility,
                events = events,
                policyVersion = policy.version,
                quality = MeasurementQuality(source = "telemetry.engine")
            )
        )
        return finalState
    }

    suspend fun runUserDiagnostic(): DiagnosticRun {
        val allowed = consentRepository.isEnabled(ConsentType.DIAGNOSTIC_TESTS) && consentRepository.isEnabled(ConsentType.PERFORMANCE_MEASUREMENTS)
        if (!allowed) {
            return DiagnosticRun(
                state = _state.value,
                diagnostic = DiagnosticResult(
                    DiagnosticClassification.UNKNOWN,
                    0.0,
                    "Permission needed",
                    "Enable diagnostic and performance measurements in Privacy Center before running this check.",
                    "The diagnostic engine did not execute because consent is disabled.",
                    listOf("diagnostic consent = disabled"),
                    "Open Privacy Center to enable the required measurements."
                ),
                measurements = emptyList()
            )
        }

        val pre = refresh(CollectionTrigger.USER)
        val policy = policyRepository.current()
        val measurements = performanceEngine.runDiagnostic(policy)
        val latency = measurements.firstOrNull { it.metric == "latency_median" && it.success }?.value
        val download = measurements.firstOrNull { it.metric == "download_throughput" && it.success }?.value
        val updated = pre.copy(
            latencyMs = latency ?: pre.latencyMs,
            downloadMbps = download ?: pre.downloadMbps
        ).let { it.copy(experience = scorer.score(it)) }
        _state.value = updated

        val dns = measurements.firstOrNull { it.metric == "dns_latency" }
        val diagnostic = diagnosticEngine.diagnose(updated, dnsLatencyMs = dns?.value, dnsSucceeded = dns?.success)

        telemetryRepository.enqueue(
            TelemetryEnvelope(
                eventId = UUID.randomUUID().toString(),
                installationId = installationRepository.installationId(),
                sequenceNumber = installationRepository.nextSequence(),
                timestampMs = System.currentTimeMillis(),
                elapsedRealtimeMs = SystemClock.elapsedRealtime(),
                measurementType = MeasurementType.DIAGNOSTIC,
                trigger = CollectionTrigger.DIAGNOSTIC,
                performance = measurements,
                policyVersion = policy.version,
                quality = MeasurementQuality(
                    availability = if (measurements.any { it.success }) Availability.AVAILABLE else Availability.UNAVAILABLE,
                    source = "diagnostic.engine"
                )
            )
        )
        return DiagnosticRun(updated, diagnostic, measurements)
    }

    private fun wifiLevel(rssi: Int): Int = when {
        rssi >= -55 -> 4
        rssi >= -65 -> 3
        rssi >= -75 -> 2
        rssi >= -85 -> 1
        else -> 0
    }
}

data class DiagnosticRun(
    val state: LiveNetworkState,
    val diagnostic: DiagnosticResult,
    val measurements: List<com.umniah.networkinsights.core.model.PerformanceMeasurement>
)

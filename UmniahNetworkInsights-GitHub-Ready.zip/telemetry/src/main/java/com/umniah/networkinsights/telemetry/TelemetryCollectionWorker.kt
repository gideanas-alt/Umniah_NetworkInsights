package com.umniah.networkinsights.telemetry

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.umniah.networkinsights.core.model.CollectionTrigger
import com.umniah.networkinsights.core.model.ConsentType
import com.umniah.networkinsights.domain.ConsentRepository
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import java.util.concurrent.TimeUnit

@HiltWorker
class TelemetryCollectionWorker @AssistedInject constructor(
    @Assisted appContext: Context,
    @Assisted params: WorkerParameters,
    private val engine: TelemetryEngine,
    private val consents: ConsentRepository
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        if (!consents.isEnabled(ConsentType.BACKGROUND_MEASUREMENTS)) return Result.success()
        return runCatching { engine.refresh(CollectionTrigger.PERIODIC); Result.success() }.getOrElse { Result.retry() }
    }
}

object CollectionScheduler {
    fun ensureScheduled(context: Context) {
        val request = PeriodicWorkRequestBuilder<TelemetryCollectionWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiresBatteryNotLow(true).build())
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "telemetry-collection",
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }
}

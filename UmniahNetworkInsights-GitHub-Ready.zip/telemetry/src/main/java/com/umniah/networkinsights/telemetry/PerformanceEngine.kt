package com.umniah.networkinsights.telemetry

import com.umniah.networkinsights.core.model.Availability
import com.umniah.networkinsights.core.model.MeasurementQuality
import com.umniah.networkinsights.core.model.PerformanceMeasurement
import com.umniah.networkinsights.core.model.RemoteMeasurementPolicy
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import javax.inject.Inject
import javax.inject.Singleton
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import kotlin.math.abs

@Singleton
class PerformanceEngine @Inject constructor(private val client: OkHttpClient) {
    suspend fun runDiagnostic(policy: RemoteMeasurementPolicy): List<PerformanceMeasurement> = withContext(Dispatchers.IO) {
        val results = mutableListOf<PerformanceMeasurement>()
        results += dnsProbe(policy.latencyHost)
        val tcpSamples = (1..4).map { tcpProbe(policy.latencyHost, 443) }
        results += tcpSamples
        results += tlsProbe(policy.latencyHost, 443)
        results += httpProbe(policy.httpProbeUrl)

        val successfulTcp = tcpSamples.filter { it.success && it.value != null }.mapNotNull { it.value }
        if (successfulTcp.isNotEmpty()) {
            val sorted = successfulTcp.sorted()
            val median = sorted[sorted.size / 2]
            results += metric("latency_median", median, "ms", 0, policy.latencyHost, true, "active.tcp")
            if (successfulTcp.size > 1) {
                val jitter = successfulTcp.zipWithNext { a, b -> abs(b - a) }.average()
                results += metric("jitter", jitter, "ms", 0, policy.latencyHost, true, "active.tcp")
            }
        }
        val loss = 100.0 * tcpSamples.count { !it.success } / tcpSamples.size.coerceAtLeast(1)
        results += metric("probe_loss", loss, "%", 0, policy.latencyHost, true, "active.tcp", flags = listOf("Application-level TCP probe loss; not ICMP packet loss"))

        if (policy.enableSpeedTests && policy.downloadProbeUrl != null) {
            results += boundedDownloadProbe(policy.downloadProbeUrl, maxBytes = minOf(policy.maxDailyTestBytes, 5L * 1024L * 1024L))
        }
        results
    }

    private fun dnsProbe(host: String): PerformanceMeasurement {
        val start = System.nanoTime()
        return runCatching { InetAddress.getAllByName(host) }.fold(
            onSuccess = { metric("dns_latency", elapsedMs(start), "ms", elapsedMsLong(start), host, true, "active.dns") },
            onFailure = { failed("dns_latency", "ms", elapsedMsLong(start), host, "active.dns", it.javaClass.simpleName) }
        )
    }

    private fun tcpProbe(host: String, port: Int): PerformanceMeasurement {
        val start = System.nanoTime()
        return runCatching {
            Socket().use { it.connect(InetSocketAddress(host, port), 5_000) }
        }.fold(
            onSuccess = { metric("tcp_connect", elapsedMs(start), "ms", elapsedMsLong(start), "$host:$port", true, "active.tcp") },
            onFailure = { failed("tcp_connect", "ms", elapsedMsLong(start), "$host:$port", "active.tcp", it.javaClass.simpleName) }
        )
    }

    private fun tlsProbe(host: String, port: Int): PerformanceMeasurement {
        val start = System.nanoTime()
        return runCatching {
            val factory = SSLSocketFactory.getDefault() as SSLSocketFactory
            (factory.createSocket() as SSLSocket).use { socket ->
                socket.soTimeout = 5_000
                socket.connect(InetSocketAddress(host, port), 5_000)
                socket.startHandshake()
            }
        }.fold(
            onSuccess = { metric("tls_handshake", elapsedMs(start), "ms", elapsedMsLong(start), "$host:$port", true, "active.tls") },
            onFailure = { failed("tls_handshake", "ms", elapsedMsLong(start), "$host:$port", "active.tls", it.javaClass.simpleName) }
        )
    }

    private fun httpProbe(url: String): PerformanceMeasurement {
        val start = System.nanoTime()
        return runCatching {
            client.newCall(Request.Builder().url(url).head().build()).execute().use { response ->
                if (!response.isSuccessful && response.code >= 500) error("HTTP ${response.code}")
            }
        }.fold(
            onSuccess = { metric("http_response", elapsedMs(start), "ms", elapsedMsLong(start), url, true, "active.http") },
            onFailure = { failed("http_response", "ms", elapsedMsLong(start), url, "active.http", it.javaClass.simpleName) }
        )
    }

    private fun boundedDownloadProbe(url: String, maxBytes: Long): PerformanceMeasurement {
        val start = System.nanoTime()
        var bytes = 0L
        return runCatching {
            client.newCall(Request.Builder().url(url).header("Range", "bytes=0-${maxBytes - 1}").build()).execute().use { response ->
                if (!response.isSuccessful) error("HTTP ${response.code}")
                val source = response.body?.source() ?: error("No response body")
                val buffer = okio.Buffer()
                while (bytes < maxBytes) {
                    val read = source.read(buffer, minOf(64L * 1024L, maxBytes - bytes))
                    if (read <= 0) break
                    bytes += read
                    buffer.clear()
                }
            }
            val seconds = (System.nanoTime() - start) / 1_000_000_000.0
            if (seconds <= 0.0) error("Invalid duration")
            (bytes * 8.0 / 1_000_000.0) / seconds
        }.fold(
            onSuccess = { metric("download_throughput", it, "Mbps", elapsedMsLong(start), url, true, "active.download", flags = listOf("Bounded diagnostic transfer")) },
            onFailure = { failed("download_throughput", "Mbps", elapsedMsLong(start), url, "active.download", it.javaClass.simpleName) }
        )
    }

    private fun metric(name: String, value: Double, unit: String, duration: Long, endpoint: String?, success: Boolean, source: String, flags: List<String> = emptyList()) =
        PerformanceMeasurement(System.currentTimeMillis(), name, value, unit, duration, endpoint, success, MeasurementQuality(source = source, flags = flags))

    private fun failed(name: String, unit: String, duration: Long, endpoint: String?, source: String, reason: String) =
        PerformanceMeasurement(System.currentTimeMillis(), name, null, unit, duration, endpoint, false, MeasurementQuality(Availability.UNAVAILABLE, source, confidence = 0.0, flags = listOf(reason)))

    private fun elapsedMs(startNanos: Long): Double = (System.nanoTime() - startNanos) / 1_000_000.0
    private fun elapsedMsLong(startNanos: Long): Long = ((System.nanoTime() - startNanos) / 1_000_000L).coerceAtLeast(0L)
}

package com.umniah.networkinsights.telemetry

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import com.umniah.networkinsights.core.model.CollectionTrigger
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Event-driven runtime: reacts to connectivity changes and debounces snapshots. */
@Singleton
class TelemetryRuntime @Inject constructor(
    @ApplicationContext private val context: Context,
    private val engine: TelemetryEngine
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var debounceJob: Job? = null
    private var started = false

    fun start() {
        if (started) return
        started = true
        val cm = context.getSystemService(ConnectivityManager::class.java)
        cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) = trigger()
            override fun onLost(network: Network) = trigger()
            override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) = trigger()
        })
        trigger()
    }

    private fun trigger() {
        debounceJob?.cancel()
        debounceJob = scope.launch {
            delay(1_200)
            runCatching { engine.refresh(CollectionTrigger.CHANGE) }
        }
    }
}

package com.umniah.networkinsights.telemetry

import android.content.Context
import android.os.Build
import android.telephony.CellIdentityGsm
import android.telephony.CellIdentityLte
import android.telephony.CellIdentityNr
import android.telephony.CellIdentityWcdma
import android.telephony.CellInfo
import android.telephony.CellInfoGsm
import android.telephony.CellInfoLte
import android.telephony.CellInfoNr
import android.telephony.CellInfoWcdma
import android.telephony.SubscriptionManager
import android.telephony.TelephonyCallback
import android.telephony.TelephonyDisplayInfo
import android.telephony.TelephonyManager
import com.umniah.networkinsights.core.model.Availability
import com.umniah.networkinsights.core.model.CellMeasurement
import com.umniah.networkinsights.core.model.FiveGArchitecture
import com.umniah.networkinsights.core.model.MeasurementQuality
import com.umniah.networkinsights.core.model.NetworkTechnology
import com.umniah.networkinsights.core.model.RadioSnapshot
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DisplayInfoTracker @Inject constructor(
    @ApplicationContext private val context: Context,
    private val permissions: PermissionGate
) {
    @Volatile private var overrideType: Int? = null
    private var activeSubId: Int? = null
    private var activeManager: TelephonyManager? = null
    private var callback: TelephonyCallback? = null

    @Synchronized
    fun ensureStarted(subscriptionId: Int) {
        if (Build.VERSION.SDK_INT < 31 || activeSubId == subscriptionId || !permissions.snapshot().phoneState) return
        stopLocked()
        val manager = context.getSystemService(TelephonyManager::class.java).createForSubscriptionId(subscriptionId)
        val cb = object : TelephonyCallback(), TelephonyCallback.DisplayInfoListener {
            override fun onDisplayInfoChanged(telephonyDisplayInfo: TelephonyDisplayInfo) {
                overrideType = telephonyDisplayInfo.overrideNetworkType
            }
        }
        runCatching { manager.registerTelephonyCallback(context.mainExecutor, cb) }
            .onSuccess {
                activeSubId = subscriptionId
                activeManager = manager
                callback = cb
            }
    }

    fun currentName(): String? = overrideType?.let(::displayOverrideName)

    @Synchronized
    private fun stopLocked() {
        if (Build.VERSION.SDK_INT >= 31) {
            val manager = activeManager
            val cb = callback
            if (manager != null && cb != null) runCatching { manager.unregisterTelephonyCallback(cb) }
        }
        activeManager = null
        callback = null
        activeSubId = null
        overrideType = null
    }

    private fun displayOverrideName(value: Int): String = when (value) {
        TelephonyDisplayInfo.OVERRIDE_NETWORK_TYPE_NONE -> "NONE"
        TelephonyDisplayInfo.OVERRIDE_NETWORK_TYPE_LTE_CA -> "LTE_CA"
        TelephonyDisplayInfo.OVERRIDE_NETWORK_TYPE_LTE_ADVANCED_PRO -> "LTE_ADVANCED_PRO"
        TelephonyDisplayInfo.OVERRIDE_NETWORK_TYPE_NR_NSA -> "NR_NSA"
        TelephonyDisplayInfo.OVERRIDE_NETWORK_TYPE_NR_ADVANCED -> "NR_ADVANCED"
        else -> "OVERRIDE_$value"
    }
}

@Singleton
class RadioCollector @Inject constructor(
    @ApplicationContext private val context: Context,
    private val permissions: PermissionGate,
    private val displayInfoTracker: DisplayInfoTracker
) {
    fun collect(): RadioSnapshot {
        val now = System.currentTimeMillis()
        val defaultSubId = SubscriptionManager.getDefaultDataSubscriptionId()
        val baseTm = context.getSystemService(TelephonyManager::class.java)
        val tm = if (SubscriptionManager.isValidSubscriptionId(defaultSubId)) baseTm.createForSubscriptionId(defaultSubId) else baseTm
        if (SubscriptionManager.isValidSubscriptionId(defaultSubId)) displayInfoTracker.ensureStarted(defaultSubId)

        val phoneAllowed = permissions.snapshot().phoneState
        val fineAllowed = permissions.snapshot().fineLocation
        val dataNetworkType = if (phoneAllowed) runCatching { tm.dataNetworkType }.getOrDefault(TelephonyManager.NETWORK_TYPE_UNKNOWN) else TelephonyManager.NETWORK_TYPE_UNKNOWN
        val technology = mapNetworkType(dataNetworkType)
        val serviceState = if (phoneAllowed) runCatching { tm.serviceState }.getOrNull() else null
        val signalLevel = if (Build.VERSION.SDK_INT >= 28) runCatching { tm.signalStrength?.level }.getOrNull() else null
        val cells = if (fineAllowed) runCatching { tm.allCellInfo.orEmpty().mapNotNull { toMeasurement(it, defaultSubId.takeIf(SubscriptionManager::isValidSubscriptionId), now) } }.getOrDefault(emptyList()) else emptyList()
        val displayOverride = displayInfoTracker.currentName()
        val nrObserved = cells.any { it.technology == NetworkTechnology.NR }
        val nrRegistered = cells.any { it.technology == NetworkTechnology.NR && it.registered }
        val (arch, confidence) = classify5g(technology, displayOverride, nrObserved, nrRegistered)

        val quality = when {
            !phoneAllowed -> MeasurementQuality(Availability.PERMISSION_MISSING, "android.telephony", confidence = 0.0, permissionState = "READ_PHONE_STATE missing")
            !fineAllowed -> MeasurementQuality(Availability.PARTIAL, "android.telephony", confidence = 0.8, permissionState = "ACCESS_FINE_LOCATION missing; cell details unavailable")
            else -> MeasurementQuality(source = "android.telephony", confidence = if (cells.isEmpty()) 0.7 else 1.0)
        }

        return RadioSnapshot(
            timestampMs = now,
            subscriptionId = defaultSubId.takeIf(SubscriptionManager::isValidSubscriptionId),
            technology = technology,
            dataConnected = serviceState?.state == android.telephony.ServiceState.STATE_IN_SERVICE && dataNetworkType != TelephonyManager.NETWORK_TYPE_UNKNOWN,
            roaming = runCatching { tm.isNetworkRoaming }.getOrDefault(false),
            operatorName = serviceState?.operatorAlphaLong?.toString()?.takeIf { it.isNotBlank() },
            signalLevel = signalLevel,
            architecture5g = arch,
            architectureConfidence = confidence,
            displayOverride = displayOverride,
            cells = cells,
            quality = quality
        )
    }

    private fun classify5g(
        technology: NetworkTechnology,
        displayOverride: String?,
        nrObserved: Boolean,
        nrRegistered: Boolean
    ): Pair<FiveGArchitecture, Double> = when {
        technology == NetworkTechnology.NR && nrRegistered -> FiveGArchitecture.SA to 0.88
        technology == NetworkTechnology.NR -> FiveGArchitecture.PROBABLE_SA to 0.72
        displayOverride == "NR_NSA" || displayOverride == "NR_ADVANCED" -> FiveGArchitecture.NSA to 0.90
        technology == NetworkTechnology.LTE && nrObserved -> FiveGArchitecture.PROBABLE_NSA to 0.72
        !nrObserved && technology != NetworkTechnology.NR -> FiveGArchitecture.NOT_5G to 0.95
        else -> FiveGArchitecture.UNKNOWN to 0.40
    }

    private fun toMeasurement(info: CellInfo, subId: Int?, now: Long): CellMeasurement? = when (info) {
        is CellInfoLte -> {
            val id = info.cellIdentity as CellIdentityLte
            val ss = info.cellSignalStrength
            CellMeasurement(
                now, subId, info.isRegistered, NetworkTechnology.LTE,
                mccLte(id), mncLte(id), intOrNull(id.ci)?.toLong(), intOrNull(id.tac), intOrNull(id.pci),
                if (Build.VERSION.SDK_INT >= 30) id.bands.firstOrNull() else null,
                intOrNull(id.earfcn), intOrNull(ss.rsrp), intOrNull(ss.rsrq), intOrNull(ss.rssnr), if (Build.VERSION.SDK_INT >= 29) intOrNull(ss.rssi) else null,
                intOrNull(ss.timingAdvance), MeasurementQuality(source = "android.cellinfo.lte")
            )
        }
        is CellInfoNr -> {
            if (Build.VERSION.SDK_INT < 29) return null
            val id = info.cellIdentity as CellIdentityNr
            val ss = info.cellSignalStrength
            CellMeasurement(
                now, subId, info.isRegistered, NetworkTechnology.NR,
                id.mccString, id.mncString, longOrNull(id.nci), intOrNull(id.tac), intOrNull(id.pci),
                id.bands.firstOrNull(), intOrNull(id.nrarfcn), intOrNull(ss.ssRsrp), intOrNull(ss.ssRsrq), intOrNull(ss.ssSinr),
                null, null, MeasurementQuality(source = "android.cellinfo.nr")
            )
        }
        is CellInfoWcdma -> {
            val id = info.cellIdentity as CellIdentityWcdma
            val ss = info.cellSignalStrength
            CellMeasurement(
                now, subId, info.isRegistered, NetworkTechnology.WCDMA,
                mccWcdma(id), mncWcdma(id), intOrNull(id.cid)?.toLong(), intOrNull(id.lac), intOrNull(id.psc), null,
                intOrNull(id.uarfcn), null, null, null, intOrNull(ss.dbm), null,
                MeasurementQuality(source = "android.cellinfo.wcdma")
            )
        }
        is CellInfoGsm -> {
            val id = info.cellIdentity as CellIdentityGsm
            val ss = info.cellSignalStrength
            CellMeasurement(
                now, subId, info.isRegistered, NetworkTechnology.GSM,
                mccGsm(id), mncGsm(id), intOrNull(id.cid)?.toLong(), intOrNull(id.lac), intOrNull(id.bsic), null,
                intOrNull(id.arfcn), null, null, null, intOrNull(ss.dbm), null,
                MeasurementQuality(source = "android.cellinfo.gsm")
            )
        }
        else -> null
    }


    private fun mccLte(id: CellIdentityLte): String? = if (Build.VERSION.SDK_INT >= 28) id.mccString else intOrNull(id.mcc)?.toString()?.padStart(3, '0')
    private fun mncLte(id: CellIdentityLte): String? = if (Build.VERSION.SDK_INT >= 28) id.mncString else intOrNull(id.mnc)?.toString()?.padStart(2, '0')
    private fun mccWcdma(id: CellIdentityWcdma): String? = if (Build.VERSION.SDK_INT >= 28) id.mccString else intOrNull(id.mcc)?.toString()?.padStart(3, '0')
    private fun mncWcdma(id: CellIdentityWcdma): String? = if (Build.VERSION.SDK_INT >= 28) id.mncString else intOrNull(id.mnc)?.toString()?.padStart(2, '0')
    private fun mccGsm(id: CellIdentityGsm): String? = if (Build.VERSION.SDK_INT >= 28) id.mccString else intOrNull(id.mcc)?.toString()?.padStart(3, '0')
    private fun mncGsm(id: CellIdentityGsm): String? = if (Build.VERSION.SDK_INT >= 28) id.mncString else intOrNull(id.mnc)?.toString()?.padStart(2, '0')

    private fun intOrNull(value: Int): Int? = value.takeUnless { it == CellInfo.UNAVAILABLE || it == Int.MAX_VALUE || it == Int.MIN_VALUE }
    private fun longOrNull(value: Long): Long? = value.takeUnless { it == CellInfo.UNAVAILABLE_LONG || it == Long.MAX_VALUE || it < 0L }

    private fun mapNetworkType(type: Int): NetworkTechnology = when (type) {
        TelephonyManager.NETWORK_TYPE_GPRS, TelephonyManager.NETWORK_TYPE_EDGE, TelephonyManager.NETWORK_TYPE_GSM -> NetworkTechnology.GSM
        TelephonyManager.NETWORK_TYPE_UMTS, TelephonyManager.NETWORK_TYPE_HSDPA, TelephonyManager.NETWORK_TYPE_HSUPA,
        TelephonyManager.NETWORK_TYPE_HSPA, TelephonyManager.NETWORK_TYPE_HSPAP, TelephonyManager.NETWORK_TYPE_TD_SCDMA -> NetworkTechnology.WCDMA
        TelephonyManager.NETWORK_TYPE_LTE -> NetworkTechnology.LTE
        TelephonyManager.NETWORK_TYPE_NR -> NetworkTechnology.NR
        else -> NetworkTechnology.UNKNOWN
    }
}

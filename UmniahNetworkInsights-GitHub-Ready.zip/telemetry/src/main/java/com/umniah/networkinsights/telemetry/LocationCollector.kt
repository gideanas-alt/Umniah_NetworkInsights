package com.umniah.networkinsights.telemetry

import android.content.Context
import android.location.Location
import android.location.LocationManager
import com.umniah.networkinsights.core.model.Availability
import com.umniah.networkinsights.core.model.LocationMeasurement
import com.umniah.networkinsights.core.model.MeasurementQuality
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LocationCollector @Inject constructor(
    @ApplicationContext private val context: Context,
    private val permissions: PermissionGate
) {
    /**
     * Uses only a cached platform location for routine telemetry. Active GNSS acquisition is intentionally
     * reserved for an explicit user journey so background collection does not wake sensors aggressively.
     */
    fun collect(preciseConsent: Boolean, approximateConsent: Boolean): LocationMeasurement? {
        val p = permissions.snapshot()
        if (!approximateConsent && !preciseConsent) return null
        if (!p.coarseLocation && !p.fineLocation) {
            return LocationMeasurement(
                System.currentTimeMillis(), null, null, null, null, null, null, null, null,
                privacyLevel = if (preciseConsent) "PRECISE" else "APPROXIMATE",
                quality = MeasurementQuality(Availability.PERMISSION_MISSING, "android.location", confidence = 0.0, permissionState = "Location permission missing")
            )
        }
        val lm = context.getSystemService(LocationManager::class.java)
        val providers = runCatching { lm.getProviders(true) }.getOrDefault(emptyList())
        val best = providers.mapNotNull { provider -> runCatching { lm.getLastKnownLocation(provider) }.getOrNull() }
            .maxByOrNull(Location::getTime)

        if (best == null) {
            return LocationMeasurement(
                System.currentTimeMillis(), null, null, null, null, null, null, null, null,
                privacyLevel = if (preciseConsent) "PRECISE" else "APPROXIMATE",
                quality = MeasurementQuality(Availability.UNAVAILABLE, "android.location", confidence = 0.0, flags = listOf("No cached location available"))
            )
        }

        val precise = preciseConsent && p.fineLocation
        val precision = if (precise) 8 else 5
        return LocationMeasurement(
            timestampMs = best.time,
            latitude = if (precise) best.latitude else null,
            longitude = if (precise) best.longitude else null,
            geohash = GeoHash.encode(best.latitude, best.longitude, precision),
            accuracyM = best.accuracy.takeIf { best.hasAccuracy() },
            altitudeM = best.altitude.takeIf { best.hasAltitude() },
            speedMps = best.speed.takeIf { best.hasSpeed() },
            bearingDeg = best.bearing.takeIf { best.hasBearing() },
            source = best.provider,
            privacyLevel = if (precise) "PRECISE" else "APPROXIMATE",
            quality = MeasurementQuality(source = "android.location", accuracy = best.accuracy.toDouble(), confidence = if (precise) 1.0 else 0.75)
        )
    }
}

object GeoHash {
    private const val BASE32 = "0123456789bcdefghjkmnpqrstuvwxyz"

    fun encode(latitude: Double, longitude: Double, precision: Int): String {
        var latMin = -90.0; var latMax = 90.0
        var lonMin = -180.0; var lonMax = 180.0
        var even = true
        var bit = 0
        var ch = 0
        val out = StringBuilder()
        while (out.length < precision) {
            if (even) {
                val mid = (lonMin + lonMax) / 2
                if (longitude >= mid) { ch = ch or (1 shl (4 - bit)); lonMin = mid } else lonMax = mid
            } else {
                val mid = (latMin + latMax) / 2
                if (latitude >= mid) { ch = ch or (1 shl (4 - bit)); latMin = mid } else latMax = mid
            }
            even = !even
            if (bit < 4) bit++ else {
                out.append(BASE32[ch])
                bit = 0
                ch = 0
            }
        }
        return out.toString()
    }
}

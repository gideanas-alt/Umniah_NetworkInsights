package com.umniah.networkinsights.telemetry

import android.content.Context
import android.os.Build
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import com.umniah.networkinsights.core.model.Availability
import com.umniah.networkinsights.core.model.MeasurementQuality
import com.umniah.networkinsights.core.model.SubscriptionSnapshot
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SubscriptionCollector @Inject constructor(
    @ApplicationContext private val context: Context,
    private val permissions: PermissionGate
) {
    fun collect(): List<SubscriptionSnapshot> {
        if (!permissions.snapshot().phoneState) return emptyList()
        val sm = context.getSystemService(SubscriptionManager::class.java)
        val baseTm = context.getSystemService(TelephonyManager::class.java)
        val defaultData = SubscriptionManager.getDefaultDataSubscriptionId()
        return runCatching { sm.activeSubscriptionInfoList.orEmpty() }.getOrDefault(emptyList()).map { info ->
            val tm = baseTm.createForSubscriptionId(info.subscriptionId)
            SubscriptionSnapshot(
                timestampMs = System.currentTimeMillis(),
                subscriptionId = info.subscriptionId,
                slotIndex = info.simSlotIndex,
                carrierId = if (Build.VERSION.SDK_INT >= 29) info.carrierId.takeIf { it >= 0 } else null,
                carrierName = info.carrierName?.toString(),
                mcc = if (Build.VERSION.SDK_INT >= 29) info.mccString else info.mcc.takeIf { it > 0 }?.toString()?.padStart(3, '0'),
                mnc = if (Build.VERSION.SDK_INT >= 29) info.mncString else info.mnc.takeIf { it >= 0 }?.toString()?.padStart(2, '0'),
                roaming = runCatching { tm.isNetworkRoaming }.getOrDefault(false),
                isDefaultData = info.subscriptionId == defaultData,
                quality = MeasurementQuality(source = "android.subscription")
            )
        }
    }
}

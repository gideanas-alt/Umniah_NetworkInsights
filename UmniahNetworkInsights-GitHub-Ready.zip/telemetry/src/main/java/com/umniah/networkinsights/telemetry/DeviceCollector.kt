package com.umniah.networkinsights.telemetry

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.os.StatFs
import android.os.SystemClock
import com.umniah.networkinsights.core.model.DeviceSnapshot
import com.umniah.networkinsights.core.model.MeasurementQuality
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DeviceCollector @Inject constructor(@ApplicationContext private val context: Context) {
    fun collect(): DeviceSnapshot {
        val now = System.currentTimeMillis()
        val activity = context.getSystemService(ActivityManager::class.java)
        val memory = ActivityManager.MemoryInfo().also(activity::getMemoryInfo)
        val storage = StatFs(context.filesDir.absolutePath)
        val battery = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val status = battery?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val tempTenths = battery?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE) ?: Int.MIN_VALUE
        val power = context.getSystemService(PowerManager::class.java)
        val packageInfo = context.packageManager.getPackageInfo(context.packageName, 0)

        return DeviceSnapshot(
            timestampMs = now,
            manufacturer = Build.MANUFACTURER,
            model = Build.MODEL,
            device = Build.DEVICE,
            androidVersion = Build.VERSION.RELEASE ?: "unknown",
            sdkInt = Build.VERSION.SDK_INT,
            cpuAbis = Build.SUPPORTED_ABIS.toList(),
            memoryClassMb = activity.memoryClass,
            totalRamMb = memory.totalMem / 1024L / 1024L,
            availableStorageMb = storage.availableBytes / 1024L / 1024L,
            batteryPercent = if (level >= 0 && scale > 0) (level * 100 / scale) else null,
            charging = if (status >= 0) status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL else null,
            batteryTemperatureC = if (tempTenths != Int.MIN_VALUE) tempTenths / 10.0 else null,
            thermalStatus = if (Build.VERSION.SDK_INT >= 29) power.currentThermalStatus else null,
            uptimeMs = SystemClock.elapsedRealtime(),
            appVersion = packageInfo.versionName ?: "unknown",
            quality = MeasurementQuality(source = "android.device")
        )
    }
}

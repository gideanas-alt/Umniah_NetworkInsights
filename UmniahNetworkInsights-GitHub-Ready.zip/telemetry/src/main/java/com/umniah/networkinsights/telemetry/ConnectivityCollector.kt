package com.umniah.networkinsights.telemetry

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiInfo
import android.net.wifi.WifiManager
import android.os.Build
import com.umniah.networkinsights.core.model.Availability
import com.umniah.networkinsights.core.model.ConnectivitySnapshot
import com.umniah.networkinsights.core.model.MeasurementQuality
import com.umniah.networkinsights.core.model.TransportType
import com.umniah.networkinsights.core.model.WifiSnapshot
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ConnectivityCollector @Inject constructor(@ApplicationContext private val context: Context) {
    fun collect(): ConnectivitySnapshot {
        val cm = context.getSystemService(ConnectivityManager::class.java)
        val network = cm.activeNetwork
        val caps = network?.let(cm::getNetworkCapabilities)
        val transport = when {
            caps == null -> TransportType.NONE
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> TransportType.CELLULAR
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> TransportType.WIFI
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> TransportType.ETHERNET
            caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> TransportType.VPN
            else -> TransportType.OTHER
        }
        return ConnectivitySnapshot(
            timestampMs = System.currentTimeMillis(),
            transport = transport,
            validated = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true,
            captivePortal = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_CAPTIVE_PORTAL) == true,
            metered = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED) != true,
            downstreamKbpsEstimate = caps?.linkDownstreamBandwidthKbps?.takeIf { it > 0 },
            upstreamKbpsEstimate = caps?.linkUpstreamBandwidthKbps?.takeIf { it > 0 },
            quality = MeasurementQuality(
                availability = if (caps == null) Availability.UNAVAILABLE else Availability.AVAILABLE,
                source = "android.connectivity"
            )
        )
    }
}

@Singleton
class WifiCollector @Inject constructor(@ApplicationContext private val context: Context) {
    fun collect(): WifiSnapshot {
        val cm = context.getSystemService(ConnectivityManager::class.java)
        val active = cm.activeNetwork
        val caps = active?.let(cm::getNetworkCapabilities)
        val isWifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        val wifiManager = context.applicationContext.getSystemService(WifiManager::class.java)
        val info = if (isWifi) {
            if (Build.VERSION.SDK_INT >= 31) caps?.transportInfo as? WifiInfo else @Suppress("DEPRECATION") wifiManager.connectionInfo
        } else null
        val freq = info?.frequency?.takeIf { it > 0 }
        return WifiSnapshot(
            timestampMs = System.currentTimeMillis(),
            connected = isWifi,
            frequencyMhz = freq,
            band = freq?.let(::bandFromFrequency),
            rssiDbm = info?.rssi?.takeIf { it > -127 },
            linkSpeedMbps = info?.linkSpeed?.takeIf { it > 0 },
            rxLinkSpeedMbps = if (Build.VERSION.SDK_INT >= 29) info?.rxLinkSpeedMbps?.takeIf { it > 0 } else null,
            txLinkSpeedMbps = if (Build.VERSION.SDK_INT >= 29) info?.txLinkSpeedMbps?.takeIf { it > 0 } else null,
            wifiStandard = if (Build.VERSION.SDK_INT >= 30) info?.wifiStandard?.let(::wifiStandardName) else null,
            networkValidated = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true,
            quality = MeasurementQuality(
                availability = if (isWifi) Availability.AVAILABLE else Availability.UNAVAILABLE,
                source = "android.wifi",
                flags = listOf("SSID/BSSID intentionally not collected by baseline build")
            )
        )
    }

    private fun bandFromFrequency(mhz: Int): String = when (mhz) {
        in 2400..2500 -> "2.4 GHz"
        in 4900..5900 -> "5 GHz"
        in 5925..7125 -> "6 GHz"
        else -> "Other"
    }

    private fun wifiStandardName(value: Int): String = when (value) {
        WifiInfo.WIFI_STANDARD_LEGACY -> "Legacy"
        WifiInfo.WIFI_STANDARD_11N -> "Wi-Fi 4"
        WifiInfo.WIFI_STANDARD_11AC -> "Wi-Fi 5"
        WifiInfo.WIFI_STANDARD_11AX -> "Wi-Fi 6/6E"
        WifiInfo.WIFI_STANDARD_11BE -> "Wi-Fi 7"
        else -> "Unknown"
    }
}

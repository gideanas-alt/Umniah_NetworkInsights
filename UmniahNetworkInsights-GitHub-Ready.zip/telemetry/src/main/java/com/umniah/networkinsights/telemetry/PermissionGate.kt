package com.umniah.networkinsights.telemetry

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import javax.inject.Inject
import javax.inject.Singleton

data class PermissionSnapshot(
    val phoneState: Boolean,
    val coarseLocation: Boolean,
    val fineLocation: Boolean
)

@Singleton
class PermissionGate @Inject constructor(private val context: Context) {
    fun snapshot() = PermissionSnapshot(
        phoneState = granted(Manifest.permission.READ_PHONE_STATE),
        coarseLocation = granted(Manifest.permission.ACCESS_COARSE_LOCATION),
        fineLocation = granted(Manifest.permission.ACCESS_FINE_LOCATION)
    )

    fun granted(permission: String): Boolean = context.checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED
}

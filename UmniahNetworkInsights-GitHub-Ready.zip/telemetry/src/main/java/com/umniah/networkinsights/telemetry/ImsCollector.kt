package com.umniah.networkinsights.telemetry

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.telephony.AccessNetworkConstants
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import android.telephony.ims.ImsManager
import android.telephony.ims.ImsMmTelManager
import android.telephony.ims.RegistrationManager
import android.telephony.ims.feature.MmTelFeature
import com.umniah.networkinsights.core.model.Availability
import com.umniah.networkinsights.core.model.ImsSnapshot
import com.umniah.networkinsights.core.model.MeasurementQuality
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

@Singleton
class ImsCollector @Inject constructor(@ApplicationContext private val context: Context) {
    suspend fun collect(): ImsSnapshot {
        val now = System.currentTimeMillis()
        if (Build.VERSION.SDK_INT < 30 || !context.packageManager.hasSystemFeature(PackageManager.FEATURE_TELEPHONY_IMS)) {
            return unavailable(now, Availability.UNSUPPORTED_API, "IMS API or device IMS feature unavailable")
        }
        val subId = SubscriptionManager.getDefaultDataSubscriptionId()
        if (!SubscriptionManager.isValidSubscriptionId(subId)) return unavailable(now, Availability.UNAVAILABLE, "No active default data subscription")
        val tm = context.getSystemService(TelephonyManager::class.java).createForSubscriptionId(subId)
        val carrierPrivileges = runCatching { tm.hasCarrierPrivileges() }.getOrDefault(false)
        if (!carrierPrivileges) {
            return ImsSnapshot(
                now, subId, false, null, null, null, null, null,
                MeasurementQuality(
                    availability = Availability.OEM_REDACTED,
                    source = "android.ims",
                    confidence = 0.0,
                    flags = listOf("Precise IMS state requires carrier privileges or privileged phone-state access")
                )
            )
        }

        val mmTel = runCatching { context.getSystemService(ImsManager::class.java).getImsMmTelManager(subId) }.getOrNull()
            ?: return unavailable(now, Availability.UNAVAILABLE, "ImsMmTelManager unavailable", subId, carrierPrivileges)
        val registration = withTimeoutOrNull(1_500) { awaitRegistration(mmTel) }
        val voiceCapable = withTimeoutOrNull(1_500) { awaitVoiceCapability(mmTel) }
        val transport = registration?.second
        val registered = registration?.first
        val transportName = when (transport) {
            AccessNetworkConstants.TRANSPORT_TYPE_WWAN -> "CELLULAR"
            AccessNetworkConstants.TRANSPORT_TYPE_WLAN -> "WIFI"
            null -> null
            else -> "TRANSPORT_$transport"
        }
        val available = registered == true && voiceCapable == true
        return ImsSnapshot(
            timestampMs = now,
            subscriptionId = subId,
            carrierPrivileges = true,
            registered = registered,
            registrationTransport = transportName,
            voiceCapabilityAvailable = voiceCapable,
            volteAvailable = available.takeIf { transportName == "CELLULAR" },
            vowifiAvailable = available.takeIf { transportName == "WIFI" },
            quality = MeasurementQuality(
                availability = if (registration == null && voiceCapable == null) Availability.UNAVAILABLE else Availability.AVAILABLE,
                source = "android.ims",
                confidence = if (registration != null) 0.9 else 0.5,
                flags = listOf("Carrier-privileged path")
            )
        )
    }

    private suspend fun awaitRegistration(manager: ImsMmTelManager): Pair<Boolean, Int?>? = suspendCancellableCoroutine { continuation ->
        var completed = false
        val callback = object : RegistrationManager.RegistrationCallback() {
            override fun onRegistered(imsTransportType: Int) = finish(true, imsTransportType)
            override fun onRegistering(imsTransportType: Int) = finish(false, imsTransportType)
            override fun onUnregistered(info: android.telephony.ims.ImsReasonInfo) = finish(false, null)
            private fun finish(registered: Boolean, transport: Int?) {
                if (completed) return
                completed = true
                runCatching { manager.unregisterImsRegistrationCallback(this) }
                if (continuation.isActive) continuation.resume(registered to transport)
            }
        }
        runCatching { manager.registerImsRegistrationCallback(context.mainExecutor, callback) }
            .onFailure { if (continuation.isActive) continuation.resume(null) }
        continuation.invokeOnCancellation { runCatching { manager.unregisterImsRegistrationCallback(callback) } }
    }

    private suspend fun awaitVoiceCapability(manager: ImsMmTelManager): Boolean? = suspendCancellableCoroutine { continuation ->
        var completed = false
        val callback = object : ImsMmTelManager.CapabilityCallback() {
            override fun onCapabilitiesStatusChanged(capabilities: MmTelFeature.MmTelCapabilities) {
                if (completed) return
                completed = true
                runCatching { manager.unregisterMmTelCapabilityCallback(this) }
                if (continuation.isActive) continuation.resume(capabilities.isCapable(MmTelFeature.MmTelCapabilities.CAPABILITY_TYPE_VOICE))
            }
        }
        runCatching { manager.registerMmTelCapabilityCallback(context.mainExecutor, callback) }
            .onFailure { if (continuation.isActive) continuation.resume(null) }
        continuation.invokeOnCancellation { runCatching { manager.unregisterMmTelCapabilityCallback(callback) } }
    }

    private fun unavailable(now: Long, availability: Availability, reason: String, subId: Int? = null, carrierPrivileges: Boolean = false) =
        ImsSnapshot(now, subId, carrierPrivileges, null, null, null, null, null, MeasurementQuality(availability, "android.ims", confidence = 0.0, flags = listOf(reason)))
}

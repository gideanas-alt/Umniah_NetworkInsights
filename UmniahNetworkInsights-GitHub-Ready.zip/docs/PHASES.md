# Implementation phases

This repository is organized so each phase builds on the previous one. The current bundle contains the production-oriented foundation and reference implementation for all phases, with explicit deployment gates for external/operator-controlled services.

## Phase 1 — Architecture + project foundation
Implemented: Kotlin/Compose multi-module project, Clean Architecture boundaries, Hilt, Room, DataStore, WorkManager, Retrofit/OkHttp, Kotlin serialization, Keystore encryption, app-scoped installation ID, offline queue, remote policy model.

## Phase 2 — UI/UX
Implemented: premium dark Umniah theme using brand magenta `#D60037`, Home, Network Details, Check My Network, Timeline, Map integration point, Privacy Center, Settings, and AI Network Analyst screens. The UI intentionally uses simple customer language while technical values live under progressive disclosure.

## Phase 3 — Device + SIM telemetry
Implemented: manufacturer/model/OS/SDK/ABI, RAM/storage, battery/charging/temperature, thermal state, uptime, app version, active subscriptions, slot, carrier, MCC/MNC, roaming and default-data subscription. Permanent identifiers such as IMEI/IMSI/ICCID/MSISDN are not collected.

## Phase 4 — Cellular/RAN telemetry
Implemented: default-data RAT, service state, signal level, serving/neighbor CellInfo where Android allows, LTE/NR/WCDMA/GSM normalized identities, PCI/TAC/channel/band, LTE RSRP/RSRQ/RSSNR/RSSI and NR SS-RSRP/SS-RSRQ/SS-SINR. Missing values remain null with quality metadata.

## Phase 5 — 5G intelligence
Implemented: NR detection, NSA/SA evidence model with confidence, TelephonyDisplayInfo override tracking on supported Android versions, LTE-anchor/NR observation inference, transition events, and a carrier-privileged IMS extension for registration transport and voice capability. Exact IMS/VoLTE/VoWiFi state remains unavailable to an ordinary app when Android/carrier privileges do not expose it.

## Phase 6 — Wi-Fi + connectivity
Implemented: active transport, validated Internet/captive portal, metered state, bandwidth estimates, Wi-Fi frequency/band/RSSI/link speeds/standard when exposed. SSID/BSSID are intentionally excluded from the baseline collector.

## Phase 7 — Performance testing
Implemented: user-triggered DNS, TCP, TLS, HTTP, median latency, jitter and application-level TCP probe-loss measurements. Optional bounded download testing is disabled unless remote policy enables it and a controlled endpoint is configured. There is no continuous aggressive speed testing.

## Phase 8 — Location + mobility
Implemented: consent-aware cached location, precise coordinates only with explicit precise consent, approximate geohash mode, accuracy/altitude/speed/bearing, and a conservative speed-based mobility proxy. The consumer baseline does not request background location. The production map provider/API key is a deployment integration point rather than embedded in source control.

## Phase 9 — Event engine
Implemented: technology changes, 5G connection/fallback, serving-cell changes, Internet loss/recovery and signal degradation/recovery. Events include confidence and evidence values and are persisted locally.

## Phase 10 — Backend/API
Implemented as contract: Retrofit client, offline encrypted queue, idempotent batch IDs/event IDs, WorkManager upload with retry/backoff, OpenAPI contract, PostgreSQL control-plane schema and ClickHouse analytics schema. Uploads are deliberately disabled until the production Umniah gateway/authentication configuration is supplied.

## Phase 11 — Security + privacy
Implemented: explicit consent repository/UI, no stealth collection, Android Keystore AES-GCM for local telemetry payloads, app backup exclusions, no permanent subscriber/device identifiers, no SMS/messages/photos/contacts, no embedded server/API credentials, and an explicit deployment gate for TLS pinning/authentication after production certificates are known.

## Phase 12 — Analytics + AI
Implemented: normalized telemetry envelope, data-quality flags, experience scorer, evidence-first diagnostics, ClickHouse-friendly analytics schema, local evidence-grounded assistant behavior and a server-side `/assistant/analyze` contract. A cloud model must be called by the protected backend, never directly with a secret embedded in the APK.

## Phase 13 — Testing + optimization
Implemented: unit tests for scoring, diagnostics and mobility; battery-aware/event-driven runtime; bounded active tests; WorkManager scheduling; encrypted batching; and explicit OEM/device/network test strategy in `TEST_STRATEGY.md`. Physical-device, field, backend integration and carrier-privilege certification remain release activities because they require Umniah test SIMs, network access and OEM/device labs.

## External deployment gates

The code intentionally does not invent or hard-code infrastructure that has not been supplied:

- production API gateway hostname and authentication/attestation flow;
- production certificate pins and backup/rotation pins;
- carrier privilege rules/certificates for deeper IMS access;
- controlled download/upload performance-test endpoints and budgets;
- approved map provider and API key;
- server-side AI provider/model and governance policy;
- cell/site inventory enrichment feeds;
- privacy/legal retention values approved by Umniah.

# Deployment checklist

1. Open the project in Android Studio Quail 4 or newer with JDK 17 and Android API 37 installed.
2. Configure the real API gateway in `BackendDeploymentConfig` only after installation authentication is implemented. Keep uploads disabled during UI/field-probe development if no governed backend is available.
3. Implement installation registration/token rotation and add the auth interceptor. Do not ship a reusable backend/API secret in the APK.
4. Add certificate pinning only after the production certificate chain, backup pins and rotation runbook are approved.
5. Supply controlled performance-test endpoints. Enforce per-test and per-day byte budgets server-side as well as client-side.
6. If IMS/VoLTE/VoWiFi precision is required, provision carrier privileges for the signed production package and validate on Umniah SIM/eSIM profiles.
7. Select the approved map provider and inject its key through secure build/deployment configuration; do not commit production keys.
8. Deploy the PostgreSQL control plane and ClickHouse tables, then implement schema validation/enrichment between ingestion and analytics storage.
9. Configure retention, deletion/export, consent audit and legal/privacy notices before enabling location or long-term telemetry.
10. Connect the server-side AI endpoint only after prompt/evidence governance, logging policy and model access controls are approved.
11. Run the device/network/test matrix and battery/data acceptance suite.
12. Produce a signed internal field build before public Play rollout; stage feature flags and measurement policies conservatively.

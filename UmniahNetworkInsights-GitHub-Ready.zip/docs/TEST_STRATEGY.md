# Test strategy

## Unit
- experience scoring boundaries and missing-value behavior;
- diagnostic rules and evidence wording;
- event detection and transition deduplication;
- mobility classification;
- geohash precision;
- remote policy fallback and consent intersection;
- serialization compatibility for telemetry schema versions.

## Android integration
- Room DAO persistence, migration and encrypted-payload round-trip;
- WorkManager collection/upload retry/backoff using `work-testing`;
- permission-denied and permission-revoked-at-runtime flows;
- dual-SIM/default-data-SIM changes;
- process death/restart and WorkManager rescheduling;
- network loss during batch upload and server ACK ambiguity;
- notification/foreground restrictions if a future foreground diagnostic service is added.

## Device matrix
At minimum: recent Samsung Galaxy, Google Pixel, Xiaomi/Redmi, Oppo/OnePlus and Huawei devices where relevant to the target subscriber base, across Android API 26 through 37 where supported. Include low-memory and aggressive-background-management OEM profiles.

## Network matrix
- GSM/EDGE where still available;
- WCDMA/HSPA where still available;
- LTE, LTE CA;
- 5G NSA and SA;
- Wi-Fi 5/6/6E/7 where hardware exists;
- no Internet, captive portal, VPN, roaming and dual SIM;
- stationary, pedestrian, driving and high-speed corridors;
- weak coverage, cell-edge, handover/transition and busy-hour scenarios.

## Field validation
Compare Android-exposed radio values with trusted drive-test/network tools on the same route and time window. The goal is to quantify measurement bias/device variance, not to force handset telemetry to match network counters exactly.

## Performance/battery acceptance
Run 24-hour and 72-hour tests measuring battery delta, CPU wake time, bytes transmitted, DB growth and worker execution. Verify that normal state remains sparse/event-driven and that diagnostic escalation returns to baseline automatically.

## Release gates
- zero collection before required consent;
- no precise coordinate persistence under approximate mode;
- no sensitive data in logcat/crash reports;
- schema backward compatibility;
- offline queue recovery;
- API rate/size limits;
- physical carrier-privilege verification for IMS features;
- penetration test and privacy review before production enablement.

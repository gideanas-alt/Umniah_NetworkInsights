# Security & privacy threat model

## Protected assets
- telemetry measurements and location context;
- installation identity and authentication token;
- consent state and policy version;
- backend credentials/tokens;
- operator network intelligence.

## Main threats and controls

**Telemetry exfiltration from local storage** — Queue/event payloads are AES-256-GCM encrypted with a non-exportable Android Keystore key. Backup/device-transfer rules exclude local telemetry storage.

**Secret extraction from APK** — No production API key, AI provider key, or private certificate material belongs in the app. Installation credentials are short-lived and issued by the backend.

**Replay/duplicate upload** — Event IDs, batch IDs, sequence numbers and server acknowledgements support idempotent ingestion and replay controls.

**Remote policy silently enabling sensitive collection** — Collection is always intersected with local user consent. A remote policy may disable/reduce collection but cannot grant consent.

**False engineering conclusions** — Unsupported/unavailable fields stay null and include quality/availability metadata. Diagnostic results include confidence and evidence and are phrased as possible explanations rather than definitive RCA.

**Over-collection** — No IMEI/IMSI/ICCID/MSISDN, SMS content, messages, contacts, photos, call recordings or unrelated application content in the baseline design.

**Network MITM** — TLS is mandatory. Certificate pinning is intentionally a deployment gate because pins must include a documented backup/rotation strategy; placeholder pins are worse than none.

**Compromised/rooted device** — Backend should combine anomaly detection, rate limits and optional Play Integrity/attestation. Device telemetry from a compromised handset should not automatically be treated as trusted network truth.

**AI data leakage** — Cloud AI calls must go through the governed backend with a bounded evidence bundle. Never give an on-device client a reusable provider secret.

# Android API & permission matrix

| Area | Primary APIs | Runtime permission | Baseline behavior |
|---|---|---|---|
| Connectivity | `ConnectivityManager`, `NetworkCapabilities` | none | Event-driven active-network state |
| Subscription | `SubscriptionManager` | `READ_PHONE_STATE` | Active SIM/subscription context only |
| Cellular | `TelephonyManager`, `ServiceState`, `SignalStrength` | often `READ_PHONE_STATE` | Default data subscription |
| Detailed CellInfo | `CellInfoLte/Nr/Wcdma/Gsm` | `ACCESS_FINE_LOCATION` on affected Android versions | Missing permission -> partial telemetry, never fabricated |
| 5G display state | `TelephonyCallback.DisplayInfoListener` | device/version dependent | Evidence input only; display override is not treated as modem truth |
| IMS | `ImsMmTelManager` | carrier privilege or privileged/precise phone access depending API | Carrier extension; ordinary app returns unavailable |
| Wi-Fi | `ConnectivityManager`, `WifiInfo` | version-dependent for sensitive identity fields | Baseline avoids SSID/BSSID |
| Approximate location | `LocationManager` | `ACCESS_COARSE_LOCATION` | Stores coarse geohash, not exact coordinates |
| Precise location | `LocationManager` | `ACCESS_FINE_LOCATION` | Exact coordinates only after explicit consent |
| Background location | Android location APIs | `ACCESS_BACKGROUND_LOCATION` | Not declared in consumer baseline |
| Performance | DNS/socket/TLS/OkHttp | `INTERNET` | User/policy triggered and bounded |
| Offline sync | WorkManager | `ACCESS_NETWORK_STATE`, `INTERNET` | Connected-network constraint |

Important distinction: Android may require location permission to expose CellInfo even when the application does not store GPS coordinates. The UI explains this separately from location-storage consent.

package com.umniah.networkinsights.domain

import com.umniah.networkinsights.core.model.EventType
import com.umniah.networkinsights.core.model.LiveNetworkState
import com.umniah.networkinsights.core.model.NetworkEvent
import com.umniah.networkinsights.core.model.NetworkTechnology
import java.util.UUID

class EventDetector {
    fun detect(previous: LiveNetworkState?, current: LiveNetworkState): List<NetworkEvent> {
        if (previous == null) return emptyList()
        val now = current.collectedAtMs
        val events = mutableListOf<NetworkEvent>()

        if (previous.technology != current.technology) {
            events += event(now, EventType.TECHNOLOGY_CHANGED, "Network technology changed", previous.technology.name, current.technology.name, 1, 1.0)
            if (current.technology == NetworkTechnology.NR || current.architecture5g.name.contains("NSA")) {
                events += event(now, EventType.FIVE_G_CONNECTED, "5G became available", null, current.architecture5g.name, 1, 0.9)
            } else if (previous.technology == NetworkTechnology.NR || previous.architecture5g.name.contains("NSA")) {
                events += event(now, EventType.FIVE_G_FALLBACK, "5G connection ended", previous.architecture5g.name, current.technology.name, 1, 0.9)
            }
        }
        if (previous.cell?.cellId != current.cell?.cellId && previous.cell?.cellId != null && current.cell?.cellId != null) {
            events += event(now, EventType.CELL_CHANGED, "Serving cell changed", previous.cell.cellId.toString(), current.cell.cellId.toString(), 1, 1.0)
        }
        if (previous.internetValidated && !current.internetValidated) {
            events += event(now, EventType.INTERNET_LOST, "Internet validation lost", "validated", "not validated", 3, 0.95)
        }
        if (!previous.internetValidated && current.internetValidated) {
            events += event(now, EventType.INTERNET_RECOVERED, "Internet access recovered", "not validated", "validated", 1, 0.95)
        }
        val prevRsrp = previous.rsrpDbm
        val currRsrp = current.rsrpDbm
        if (prevRsrp != null && currRsrp != null) {
            if (prevRsrp >= -105 && currRsrp < -115) events += event(now, EventType.SIGNAL_DEGRADED, "Signal became weak", "$prevRsrp dBm", "$currRsrp dBm", 2, 0.9)
            if (prevRsrp < -115 && currRsrp >= -105) events += event(now, EventType.SIGNAL_RECOVERED, "Signal recovered", "$prevRsrp dBm", "$currRsrp dBm", 1, 0.9)
        }
        return events
    }

    private fun event(now: Long, type: EventType, message: String, previous: String?, current: String?, severity: Int, confidence: Double) =
        NetworkEvent(UUID.randomUUID().toString(), now, type, message, severity, confidence, previous, current)
}

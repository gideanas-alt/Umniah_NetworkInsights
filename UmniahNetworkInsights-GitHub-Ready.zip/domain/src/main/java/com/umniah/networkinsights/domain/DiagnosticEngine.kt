package com.umniah.networkinsights.domain

import com.umniah.networkinsights.core.model.DiagnosticClassification
import com.umniah.networkinsights.core.model.DiagnosticResult
import com.umniah.networkinsights.core.model.LiveNetworkState
import com.umniah.networkinsights.core.model.TransportType

/** Evidence-first diagnostics. It describes likely classes, never a definitive operator RCA. */
class DiagnosticEngine {
    fun diagnose(state: LiveNetworkState, dnsLatencyMs: Double? = null, dnsSucceeded: Boolean? = null): DiagnosticResult {
        if (!state.connected) {
            return result(
                DiagnosticClassification.NETWORK_PERFORMANCE, 0.95,
                "No network connection",
                "Your phone is not connected to a usable network right now.",
                "The connectivity snapshot reports no active transport.",
                listOf("active transport = none"),
                "Check mobile data or Wi-Fi and try again."
            )
        }
        if (!state.internetValidated) {
            return result(
                DiagnosticClassification.INTERNET, 0.85,
                "Internet access is not validated",
                "Your phone is connected, but Android has not validated Internet access.",
                "A local link can be present while upstream Internet reachability is unavailable or captive.",
                listOf("network connected", "validated Internet = false"),
                "Reconnect to the network or complete any Wi-Fi sign-in page."
            )
        }
        if (dnsSucceeded == false) {
            return result(
                DiagnosticClassification.DNS, 0.90,
                "DNS lookup problem",
                "Internet connectivity is present, but name resolution failed during this check.",
                "The diagnostic DNS probe failed while Android still reported validated Internet access.",
                listOf("validated Internet = true", "DNS probe = failed"),
                "Retry the check. If it persists, compare with another network."
            )
        }
        if (state.transport == TransportType.WIFI && state.signalLevel != null && state.signalLevel <= 1) {
            return result(
                DiagnosticClassification.WIFI, 0.75,
                "Weak Wi-Fi signal",
                "Your Wi-Fi link appears weak and may be affecting performance.",
                "The active transport is Wi-Fi and the reported signal level is low.",
                listOf("transport = Wi-Fi", "signal level = ${state.signalLevel}/4"),
                "Move closer to the Wi-Fi access point or try mobile data."
            )
        }
        if (state.rsrpDbm != null && state.rsrpDbm < -115) {
            return result(
                DiagnosticClassification.RADIO, 0.82,
                "Weak mobile signal",
                "Mobile radio conditions are weak at your current location.",
                "The serving-cell RSRP is below the configured weak-signal threshold.",
                listOf("RSRP = ${state.rsrpDbm} dBm"),
                "Try an open area or a position nearer a window."
            )
        }
        if (dnsLatencyMs != null && dnsLatencyMs > 500) {
            return result(
                DiagnosticClassification.DNS, 0.72,
                "DNS is responding slowly",
                "Name lookups were slower than the diagnostic target during this check.",
                "DNS latency was elevated compared with the configured threshold.",
                listOf("DNS latency = ${dnsLatencyMs.toInt()} ms"),
                "Retry once to confirm whether the delay persists."
            )
        }
        if (state.latencyMs != null && state.latencyMs > 150 && (state.rsrpDbm == null || state.rsrpDbm >= -100)) {
            return result(
                DiagnosticClassification.INTERNET, 0.70,
                "Slow network response",
                "Your signal looks reasonable, but the network path is responding slowly.",
                "Good radio conditions combined with elevated application-path latency are more consistent with a non-RF delay, but this is not a definitive root cause.",
                listOfNotNull("latency = ${state.latencyMs.toInt()} ms", state.rsrpDbm?.let { "RSRP = $it dBm" }),
                "Retry the test and compare results over time."
            )
        }
        return result(
            DiagnosticClassification.NO_PROBLEM, 0.80,
            "No issue detected",
            "The measurements collected in this check look healthy.",
            "No configured diagnostic rule was triggered by the available evidence.",
            listOf("validated Internet = true") + listOfNotNull(
                state.latencyMs?.let { "latency = ${it.toInt()} ms" },
                state.rsrpDbm?.let { "RSRP = $it dBm" }
            ),
            null
        )
    }

    private fun result(
        classification: DiagnosticClassification,
        confidence: Double,
        title: String,
        userMessage: String,
        technicalExplanation: String,
        evidence: List<String>,
        recommendation: String?
    ) = DiagnosticResult(classification, confidence, title, userMessage, technicalExplanation, evidence, recommendation)
}

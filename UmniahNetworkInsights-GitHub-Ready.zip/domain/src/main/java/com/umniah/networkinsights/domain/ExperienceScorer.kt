package com.umniah.networkinsights.domain

import com.umniah.networkinsights.core.model.ExperienceGrade
import com.umniah.networkinsights.core.model.ExperienceSummary
import com.umniah.networkinsights.core.model.LiveNetworkState
import kotlin.math.roundToInt

/**
 * Customer-facing score. Thresholds are deliberately centralized and replaceable by remote policy later.
 * Missing measurements are excluded rather than fabricated or treated as zero.
 */
class ExperienceScorer(
    private val thresholds: ExperienceThresholds = ExperienceThresholds()
) {
    fun score(state: LiveNetworkState): ExperienceSummary {
        val components = mutableListOf<Pair<Int, Double>>()

        val signal = state.rsrpDbm?.let { rsrpScore(it) } ?: state.signalLevel?.let { levelScore(it) }
        signal?.let { components += it to 0.30 }

        val availability = if (!state.connected) 0 else if (state.internetValidated) 100 else 35
        components += availability to 0.25

        val responsiveness = state.latencyMs?.let { latencyScore(it) }
        responsiveness?.let { components += it to 0.20 }

        val throughput = state.downloadMbps?.let { throughputScore(it) }
        throughput?.let { components += it to 0.15 }

        val stability = if (state.lastEvents.any { it.severity >= 3 }) 55 else 90
        components += stability to 0.10

        val weight = components.sumOf { it.second }
        if (weight == 0.0) return ExperienceSummary.unavailable()
        val score = (components.sumOf { it.first * it.second } / weight).roundToInt().coerceIn(0, 100)
        val grade = when {
            score >= 85 -> ExperienceGrade.EXCELLENT
            score >= 70 -> ExperienceGrade.GOOD
            score >= 50 -> ExperienceGrade.FAIR
            else -> ExperienceGrade.POOR
        }

        val explanation = when {
            !state.connected -> "No active network connection."
            !state.internetValidated -> "Connected, but Internet access is not currently validated."
            responsiveness != null && responsiveness < 50 -> "The connection is responding more slowly than expected."
            signal != null && signal < 50 -> "Signal conditions are limiting the experience."
            throughput != null && throughput < 50 -> "Measured download performance is below the configured experience target."
            else -> "The measured network indicators look healthy."
        }

        return ExperienceSummary(
            grade = grade,
            score = score,
            signalScore = signal,
            availabilityScore = availability,
            responsivenessScore = responsiveness,
            throughputScore = throughput,
            stabilityScore = stability,
            explanation = explanation
        )
    }

    private fun rsrpScore(rsrp: Int): Int = when {
        rsrp >= thresholds.rsrpExcellent -> 100
        rsrp >= thresholds.rsrpGood -> 82
        rsrp >= thresholds.rsrpFair -> 60
        rsrp >= thresholds.rsrpPoor -> 35
        else -> 15
    }

    private fun levelScore(level: Int): Int = when (level.coerceIn(0, 4)) {
        4 -> 100
        3 -> 82
        2 -> 60
        1 -> 35
        else -> 15
    }

    private fun latencyScore(ms: Double): Int = when {
        ms <= thresholds.latencyExcellentMs -> 100
        ms <= thresholds.latencyGoodMs -> 82
        ms <= thresholds.latencyFairMs -> 60
        ms <= thresholds.latencyPoorMs -> 35
        else -> 15
    }

    private fun throughputScore(mbps: Double): Int = when {
        mbps >= thresholds.downloadExcellentMbps -> 100
        mbps >= thresholds.downloadGoodMbps -> 82
        mbps >= thresholds.downloadFairMbps -> 60
        mbps >= thresholds.downloadPoorMbps -> 35
        else -> 15
    }
}

data class ExperienceThresholds(
    val rsrpExcellent: Int = -85,
    val rsrpGood: Int = -95,
    val rsrpFair: Int = -105,
    val rsrpPoor: Int = -115,
    val latencyExcellentMs: Double = 40.0,
    val latencyGoodMs: Double = 80.0,
    val latencyFairMs: Double = 150.0,
    val latencyPoorMs: Double = 300.0,
    val downloadExcellentMbps: Double = 100.0,
    val downloadGoodMbps: Double = 30.0,
    val downloadFairMbps: Double = 10.0,
    val downloadPoorMbps: Double = 3.0
)

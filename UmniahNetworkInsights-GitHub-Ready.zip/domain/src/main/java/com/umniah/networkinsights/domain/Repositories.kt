package com.umniah.networkinsights.domain

import com.umniah.networkinsights.core.model.ConsentRecord
import com.umniah.networkinsights.core.model.ConsentType
import com.umniah.networkinsights.core.model.LiveNetworkState
import com.umniah.networkinsights.core.model.NetworkEvent
import com.umniah.networkinsights.core.model.RemoteMeasurementPolicy
import com.umniah.networkinsights.core.model.TelemetryEnvelope
import kotlinx.coroutines.flow.Flow

interface TelemetryRepository {
    suspend fun enqueue(envelope: TelemetryEnvelope)
    fun observeRecentEvents(limit: Int = 100): Flow<List<NetworkEvent>>
    suspend fun pendingPayloads(limit: Int = 250): List<StoredTelemetryPayload>
    suspend fun markUploaded(ids: List<Long>)
    suspend fun markFailed(ids: List<Long>, retryAtMs: Long)
}

data class StoredTelemetryPayload(
    val id: Long,
    val eventId: String,
    val payload: String,
    val attemptCount: Int
)

interface ConsentRepository {
    fun observeAll(): Flow<List<ConsentRecord>>
    suspend fun isEnabled(type: ConsentType): Boolean
    suspend fun set(type: ConsentType, enabled: Boolean)
}

interface PolicyRepository {
    fun observePolicy(): Flow<RemoteMeasurementPolicy>
    suspend fun current(): RemoteMeasurementPolicy
    suspend fun update(policy: RemoteMeasurementPolicy)
}

interface InstallationRepository {
    suspend fun installationId(): String
    suspend fun nextSequence(): Long
}

interface LiveStateRepository {
    val liveState: Flow<LiveNetworkState>
}

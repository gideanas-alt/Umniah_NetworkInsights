package com.umniah.networkinsights.domain

import com.umniah.networkinsights.core.model.MobilityState

/** Conservative speed-based mobility proxy. It does not claim physical activity when location speed is absent. */
class MobilityClassifier {
    fun classify(speedMps: Float?, accuracyM: Float?): MobilityState {
        if (speedMps == null || speedMps < 0f) return MobilityState.UNKNOWN
        if (accuracyM != null && accuracyM > 100f) return MobilityState.UNKNOWN
        return when {
            speedMps < 0.7f -> MobilityState.STATIONARY
            speedMps < 2.8f -> MobilityState.WALKING
            speedMps < 35f -> MobilityState.DRIVING
            else -> MobilityState.HIGH_SPEED
        }
    }
}

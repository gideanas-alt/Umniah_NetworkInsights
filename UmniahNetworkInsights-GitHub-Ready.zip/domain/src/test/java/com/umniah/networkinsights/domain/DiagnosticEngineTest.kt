package com.umniah.networkinsights.domain

import com.umniah.networkinsights.core.model.DiagnosticClassification
import com.umniah.networkinsights.core.model.LiveNetworkState
import com.umniah.networkinsights.core.model.TransportType
import org.junit.Assert.assertEquals
import org.junit.Test

class DiagnosticEngineTest {
    @Test fun dnsFailureIsClassifiedAsDnsWhenInternetValidated() {
        val result = DiagnosticEngine().diagnose(
            LiveNetworkState(collectedAtMs = 1, connected = true, internetValidated = true, transport = TransportType.CELLULAR),
            dnsSucceeded = false
        )
        assertEquals(DiagnosticClassification.DNS, result.classification)
    }
}

package com.umniah.networkinsights.domain

import com.umniah.networkinsights.core.model.MobilityState
import org.junit.Assert.assertEquals
import org.junit.Test

class MobilityClassifierTest {
    private val classifier = MobilityClassifier()

    @Test fun classifiesConservativeSpeedBands() {
        assertEquals(MobilityState.STATIONARY, classifier.classify(0.2f, 10f))
        assertEquals(MobilityState.WALKING, classifier.classify(1.4f, 10f))
        assertEquals(MobilityState.DRIVING, classifier.classify(15f, 10f))
        assertEquals(MobilityState.HIGH_SPEED, classifier.classify(40f, 10f))
    }

    @Test fun poorAccuracyReturnsUnknown() {
        assertEquals(MobilityState.UNKNOWN, classifier.classify(10f, 250f))
    }
}

package com.umniah.networkinsights.domain

import com.umniah.networkinsights.core.model.ExperienceGrade
import com.umniah.networkinsights.core.model.LiveNetworkState
import com.umniah.networkinsights.core.model.NetworkTechnology
import com.umniah.networkinsights.core.model.TransportType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExperienceScorerTest {
    private val scorer = ExperienceScorer()

    @Test fun healthyMeasurementsScoreHigh() {
        val result = scorer.score(LiveNetworkState(
            collectedAtMs = 1,
            technology = NetworkTechnology.NR,
            connected = true,
            internetValidated = true,
            transport = TransportType.CELLULAR,
            rsrpDbm = -82,
            latencyMs = 25.0,
            downloadMbps = 150.0
        ))
        assertEquals(ExperienceGrade.EXCELLENT, result.grade)
        assertTrue((result.score ?: 0) >= 85)
    }

    @Test fun disconnectedIsPoor() {
        val result = scorer.score(LiveNetworkState(collectedAtMs = 1, connected = false))
        assertEquals(ExperienceGrade.POOR, result.grade)
    }
}

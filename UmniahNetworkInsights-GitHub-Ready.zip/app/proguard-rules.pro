# Retrofit/OkHttp and Kotlin serialization provide consumer rules where required.
# Keep database schema annotations and telemetry DTO names stable for diagnostics.
-keepattributes *Annotation*

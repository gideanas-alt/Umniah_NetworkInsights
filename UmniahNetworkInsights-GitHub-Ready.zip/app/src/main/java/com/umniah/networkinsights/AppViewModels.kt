package com.umniah.networkinsights

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.umniah.networkinsights.core.model.CollectionTrigger
import com.umniah.networkinsights.core.model.ConsentRecord
import com.umniah.networkinsights.core.model.ConsentType
import com.umniah.networkinsights.core.model.DiagnosticResult
import com.umniah.networkinsights.core.model.LiveNetworkState
import com.umniah.networkinsights.core.model.NetworkEvent
import com.umniah.networkinsights.core.model.RemoteMeasurementPolicy
import com.umniah.networkinsights.domain.ConsentRepository
import com.umniah.networkinsights.domain.PolicyRepository
import com.umniah.networkinsights.domain.TelemetryRepository
import com.umniah.networkinsights.telemetry.DiagnosticRun
import com.umniah.networkinsights.telemetry.TelemetryEngine
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val engine: TelemetryEngine,
    consentRepository: ConsentRepository
) : ViewModel() {
    val uiState: StateFlow<HomeUiState> = combine(engine.state, consentRepository.observeAll()) { state, consents ->
        HomeUiState(
            network = state,
            enabled = consents.firstOrNull { it.type == ConsentType.NETWORK_MEASUREMENTS }?.mode?.name == "ENABLED"
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeUiState())

    init { viewModelScope.launch { engine.refresh(CollectionTrigger.USER) } }
    fun refresh() { viewModelScope.launch { engine.refresh(CollectionTrigger.USER) } }
}

data class HomeUiState(val network: LiveNetworkState = LiveNetworkState(), val enabled: Boolean = false)

@HiltViewModel
class DiagnosticViewModel @Inject constructor(private val engine: TelemetryEngine) : ViewModel() {
    private val _ui = MutableStateFlow(DiagnosticUiState())
    val ui: StateFlow<DiagnosticUiState> = _ui

    fun run() {
        if (_ui.value.running) return
        viewModelScope.launch {
            _ui.value = _ui.value.copy(running = true, result = null, error = null)
            runCatching { engine.runUserDiagnostic() }
                .onSuccess { _ui.value = DiagnosticUiState(running = false, result = it) }
                .onFailure { _ui.value = DiagnosticUiState(running = false, error = "The diagnostic could not complete. Please try again.") }
        }
    }
}

data class DiagnosticUiState(val running: Boolean = false, val result: DiagnosticRun? = null, val error: String? = null)

@HiltViewModel
class TimelineViewModel @Inject constructor(repository: TelemetryRepository) : ViewModel() {
    val events: StateFlow<List<NetworkEvent>> = repository.observeRecentEvents(100)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
}

@HiltViewModel
class PrivacyViewModel @Inject constructor(private val repository: ConsentRepository) : ViewModel() {
    val consents: StateFlow<List<ConsentRecord>> = repository.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun set(type: ConsentType, enabled: Boolean) {
        viewModelScope.launch { repository.set(type, enabled) }
    }
}

@HiltViewModel
class SettingsViewModel @Inject constructor(repository: PolicyRepository) : ViewModel() {
    val policy: StateFlow<RemoteMeasurementPolicy> = repository.observePolicy()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), RemoteMeasurementPolicy())
}

@HiltViewModel
class AssistantViewModel @Inject constructor(private val engine: TelemetryEngine) : ViewModel() {
    val network = engine.state
    private val _answer = MutableStateFlow<String?>(null)
    val answer: StateFlow<String?> = _answer

    fun ask(question: String) {
        val state = network.value
        val q = question.lowercase()
        _answer.value = when {
            q.contains("slow") || q.contains("internet") -> {
                val score = state.experience
                buildString {
                    append(score.explanation)
                    state.latencyMs?.let { append(" Measured latency is ${it.toInt()} ms.") }
                    state.downloadMbps?.let { append(" Last measured download is ${"%.1f".format(it)} Mbps.") }
                    if (state.rsrpDbm != null) append(" Serving-cell RSRP is ${state.rsrpDbm} dBm.")
                    append(" This is an evidence-based explanation, not a definitive network root cause.")
                }
            }
            q.contains("signal") -> state.rsrpDbm?.let { "Your current serving-cell RSRP is $it dBm and the Android signal level is ${state.signalLevel ?: "unavailable"}/4." }
                ?: "Detailed mobile signal measurements are not currently available."
            q.contains("5g") || q.contains("4g") -> "The app currently classifies the radio as ${state.technology.name} with 5G architecture ${state.architecture5g.name}. Classification is based only on Android-exposed evidence."
            q.contains("wifi") -> "The active transport is ${state.transport.name}. ${if (state.transport.name == "WIFI") "The current experience is being measured over Wi-Fi." else "Wi-Fi is not the active transport."}"
            q.contains("today") || q.contains("performance") -> "Current experience: ${state.experience.grade.name}. Run Check My Network for fresh latency and performance measurements."
            else -> "I can explain signal quality, 4G/5G state, Wi-Fi versus mobile connectivity, and measurements from Check My Network. I only use telemetry collected on this device."
        }
    }
}

package com.umniah.networkinsights

import android.app.Application
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import com.umniah.networkinsights.core.data.SyncScheduler
import com.umniah.networkinsights.telemetry.CollectionScheduler
import com.umniah.networkinsights.telemetry.TelemetryRuntime
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

@HiltAndroidApp
class UmniahInsightsApp : Application(), Configuration.Provider {
    @Inject lateinit var workerFactory: HiltWorkerFactory
    @Inject lateinit var telemetryRuntime: TelemetryRuntime

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder().setWorkerFactory(workerFactory).build()

    override fun onCreate() {
        super.onCreate()
        telemetryRuntime.start()
        CollectionScheduler.ensureScheduled(this)
        SyncScheduler.ensureScheduled(this)
    }
}

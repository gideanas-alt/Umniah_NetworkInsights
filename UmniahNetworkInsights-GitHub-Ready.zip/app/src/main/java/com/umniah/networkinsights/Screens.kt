package com.umniah.networkinsights

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.ExpandLess
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Map
import androidx.compose.material.icons.outlined.NetworkCheck
import androidx.compose.material.icons.outlined.PrivacyTip
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.AssistChip
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import com.umniah.networkinsights.core.designsystem.GradePill
import com.umniah.networkinsights.core.designsystem.MetricTile
import com.umniah.networkinsights.core.designsystem.PremiumCard
import com.umniah.networkinsights.core.designsystem.PrimaryAction
import com.umniah.networkinsights.core.designsystem.SectionTitle
import com.umniah.networkinsights.core.designsystem.StatusDot
import com.umniah.networkinsights.core.designsystem.UmniahColors
import com.umniah.networkinsights.core.model.ConsentMode
import com.umniah.networkinsights.core.model.ConsentRecord
import com.umniah.networkinsights.core.model.ConsentType
import com.umniah.networkinsights.core.model.EventType
import com.umniah.networkinsights.core.model.ExperienceGrade
import com.umniah.networkinsights.core.model.LiveNetworkState
import com.umniah.networkinsights.core.model.NetworkEvent
import com.umniah.networkinsights.core.model.NetworkTechnology
import com.umniah.networkinsights.core.model.TransportType
import java.text.DateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
    contentPadding: PaddingValues,
    onCheck: () -> Unit,
    onDetails: () -> Unit,
    onPrivacy: () -> Unit,
    viewModel: HomeViewModel = hiltViewModel()
) {
    val ui by viewModel.uiState.collectAsState()
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(contentPadding),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                androidx.compose.foundation.Image(
                    painter = painterResource(R.drawable.umniah_logo_dark),
                    contentDescription = "Umniah by Beyon",
                    modifier = Modifier.width(168.dp).height(50.dp),
                    contentScale = ContentScale.Fit
                )
                IconButton(onClick = onPrivacy) { Icon(Icons.Outlined.PrivacyTip, "Privacy", tint = UmniahColors.TextSecondary) }
            }
        }
        item {
            Text("Your network", style = MaterialTheme.typography.headlineLarge)
            Text("A simple view of the connection your phone is experiencing now.", color = UmniahColors.TextSecondary, style = MaterialTheme.typography.bodyMedium)
        }
        if (!ui.enabled) {
            item {
                PremiumCard(highlighted = true, modifier = Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Icon(Icons.Outlined.Lock, null, tint = UmniahColors.MagentaBright)
                        Text("Network Insights is off", style = MaterialTheme.typography.titleLarge)
                        Text("Turn it on to measure connectivity, radio conditions and network experience. You stay in control of optional location and diagnostic data.", color = UmniahColors.TextSecondary)
                        PrimaryAction("Review privacy & enable", onClick = onPrivacy)
                    }
                }
            }
        } else {
            item { NetworkHero(ui.network, onDetails) }
            item { PrimaryAction("Check My Network", onClick = onCheck) }
            item {
                PremiumCard(modifier = Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Network health", style = MaterialTheme.typography.titleMedium)
                        Text(ui.network.experience.explanation, color = UmniahColors.TextSecondary, style = MaterialTheme.typography.bodyMedium)
                        if (ui.network.collectedAtMs > 0) {
                            Text("Updated ${formatTime(ui.network.collectedAtMs)}", color = UmniahColors.TextSecondary, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NetworkHero(state: LiveNetworkState, onDetails: () -> Unit) {
    PremiumCard(highlighted = true, modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text(networkLabel(state), style = MaterialTheme.typography.displaySmall)
                    Text(state.operatorName ?: transportLabel(state.transport), color = UmniahColors.TextSecondary)
                }
                GradePill(state.experience.grade)
            }
            StatusDot(if (state.internetValidated) "Internet connected" else if (state.connected) "Connected — Internet not validated" else "Not connected", state.internetValidated)
            HorizontalDivider(color = UmniahColors.Divider)
            Row(Modifier.fillMaxWidth()) {
                MetricTile("Signal", signalLabel(state), Modifier.weight(1f), state.rsrpDbm?.let { "$it dBm RSRP" })
                MetricTile("Latency", state.latencyMs?.let { "${it.toInt()} ms" } ?: "Not tested", Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth()) {
                MetricTile("Last speed", state.downloadMbps?.let { "${"%.1f".format(it)} Mbps" } ?: "Not tested", Modifier.weight(1f), "Download")
                MetricTile("Experience", state.experience.score?.let { "$it / 100" } ?: "Building", Modifier.weight(1f))
            }
            Row(
                modifier = Modifier.fillMaxWidth().clickable(onClick = onDetails).padding(top = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Network details", color = UmniahColors.MagentaBright, style = MaterialTheme.typography.labelLarge)
                Icon(Icons.Outlined.ChevronRight, null, tint = UmniahColors.MagentaBright)
            }
        }
    }
}

@Composable
fun DiagnosticScreen(onBack: () -> Unit, onPrivacy: () -> Unit, viewModel: DiagnosticViewModel = hiltViewModel()) {
    val ui by viewModel.ui.collectAsState()
    LazyColumn(
        modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { BackHeader("Check My Network", onBack) }
        item {
            Text("A short, controlled test of connectivity, DNS, responsiveness and optional bounded throughput.", color = UmniahColors.TextSecondary)
        }
        item {
            PremiumCard(highlighted = ui.running, modifier = Modifier.fillMaxWidth()) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    if (ui.running) {
                        CircularProgressIndicator(color = UmniahColors.Magenta)
                        Text("Checking your network…", style = MaterialTheme.typography.titleLarge)
                        Text("The app avoids continuous aggressive speed tests.", color = UmniahColors.TextSecondary)
                    } else {
                        Icon(Icons.Outlined.NetworkCheck, null, tint = UmniahColors.MagentaBright, modifier = Modifier.size(40.dp))
                        Text("Ready to check", style = MaterialTheme.typography.titleLarge)
                        Text("Tests run only when you ask, or when explicitly enabled by measurement policy.", color = UmniahColors.TextSecondary)
                        PrimaryAction("Start check", onClick = viewModel::run)
                    }
                }
            }
        }
        ui.error?.let { error -> item { Text(error, color = UmniahColors.Negative) } }
        ui.result?.let { run ->
            item {
                PremiumCard(modifier = Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(run.diagnostic.title, style = MaterialTheme.typography.headlineMedium)
                        Text(run.diagnostic.userMessage, color = UmniahColors.TextSecondary)
                        run.diagnostic.recommendation?.let {
                            HorizontalDivider(color = UmniahColors.Divider)
                            Text("Suggestion", style = MaterialTheme.typography.titleMedium)
                            Text(it, color = UmniahColors.TextSecondary)
                        }
                    }
                }
            }
            item { SectionTitle("Measurements", "Only values returned by completed probes are shown.") }
            items(run.measurements) { measurement ->
                DetailRow(
                    label = measurement.metric.replace('_', ' ').replaceFirstChar { it.uppercase() },
                    value = if (measurement.success && measurement.value != null) formatMeasurement(measurement.value, measurement.unit) else "Unavailable"
                )
            }
            item {
                PremiumCard(modifier = Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Technical interpretation", style = MaterialTheme.typography.titleMedium)
                        Text(run.diagnostic.technicalExplanation, color = UmniahColors.TextSecondary)
                        run.diagnostic.evidence.forEach { Text("• $it", color = UmniahColors.TextSecondary) }
                        Text("Confidence ${(run.diagnostic.confidence * 100).toInt()}%", color = UmniahColors.TextSecondary)
                    }
                }
            }
        }
        item {
            Text(
                "Diagnostic and performance measurements can be changed at any time in Privacy Center.",
                modifier = Modifier.clickable(onClick = onPrivacy),
                color = UmniahColors.MagentaBright,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
fun DetailsScreen(onBack: () -> Unit, viewModel: HomeViewModel = hiltViewModel()) {
    val ui by viewModel.uiState.collectAsState()
    val state = ui.network
    LazyColumn(
        modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { BackHeader("Network Details", onBack) }
        item {
            PremiumCard(highlighted = true, modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text(networkLabel(state), style = MaterialTheme.typography.headlineLarge)
                        Text(state.operatorName ?: "Operator unavailable", color = UmniahColors.TextSecondary)
                    }
                    GradePill(state.experience.grade)
                }
            }
        }
        item {
            ExpandableDetails("Radio", true) {
                DetailRow("Technology", networkLabel(state))
                DetailRow("5G architecture", state.architecture5g.name.replace('_', ' '))
                DetailRow("Signal level", state.signalLevel?.let { "$it / 4" } ?: "Unavailable")
                DetailRow("RSRP", state.rsrpDbm?.let { "$it dBm" } ?: "Unavailable")
                DetailRow("RSRQ", state.rsrqDb?.let { "$it dB" } ?: "Unavailable")
                DetailRow("SINR", state.sinrDb?.let { "$it dB" } ?: "Unavailable")
            }
        }
        item {
            ExpandableDetails("Serving cell") {
                val cell = state.cell
                DetailRow("MCC / MNC", if (cell?.mcc != null || cell?.mnc != null) "${cell?.mcc ?: "—"} / ${cell?.mnc ?: "—"}" else "Unavailable")
                DetailRow("Cell ID", cell?.cellId?.toString() ?: "Unavailable")
                DetailRow("TAC / LAC", cell?.tac?.toString() ?: "Unavailable")
                DetailRow("PCI / PSC / BSIC", cell?.pci?.toString() ?: "Unavailable")
                DetailRow("Band", cell?.band?.toString() ?: "Unavailable")
                DetailRow("Channel", cell?.channel?.toString() ?: "Unavailable")
            }
        }
        item {
            ExpandableDetails("Connectivity") {
                DetailRow("Transport", transportLabel(state.transport))
                DetailRow("Internet validated", if (state.internetValidated) "Yes" else "No")
                DetailRow("Connected", if (state.connected) "Yes" else "No")
                DetailRow("Last latency", state.latencyMs?.let { "${it.toInt()} ms" } ?: "Not tested")
                DetailRow("Last download", state.downloadMbps?.let { "${"%.1f".format(it)} Mbps" } ?: "Not tested")
            }
        }
        item {
            ExpandableDetails("IMS / Voice") {
                DetailRow("IMS registered", state.imsRegistered?.let { if (it) "Yes" else "No" } ?: "Unavailable")
                DetailRow("IMS transport", state.imsTransport ?: "Unavailable")
                DetailRow("VoLTE", state.volteAvailable?.let { if (it) "Available" else "Not reported available" } ?: "Unavailable")
                DetailRow("VoWiFi", state.vowifiAvailable?.let { if (it) "Available" else "Not reported available" } ?: "Unavailable")
            }
        }
        item {
            Text("Unavailable means Android did not expose that measurement, permission is missing, or the current device/network does not support it. The app does not fabricate values.", color = UmniahColors.TextSecondary, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
fun TimelineScreen(contentPadding: PaddingValues, viewModel: TimelineViewModel = hiltViewModel()) {
    val events by viewModel.events.collectAsState()
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(contentPadding),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { SectionTitle("Network Timeline", "Meaningful network transitions detected on this device.") }
        if (events.isEmpty()) {
            item {
                PremiumCard(modifier = Modifier.fillMaxWidth()) {
                    Text("No network events recorded yet. Events appear here after Network Insights is enabled and changes are observed.", color = UmniahColors.TextSecondary)
                }
            }
        } else {
            items(events, key = { it.eventId }) { event -> EventRow(event) }
        }
    }
}

@Composable
private fun EventRow(event: NetworkEvent) {
    PremiumCard(modifier = Modifier.fillMaxWidth()) {
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.Top) {
            Box(
                modifier = Modifier.size(12.dp).background(eventColor(event.type), RoundedCornerShape(100.dp))
            )
            Column(Modifier.weight(1f)) {
                Text(event.message, style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    event.previousValue?.let { Text(it, color = UmniahColors.TextSecondary, style = MaterialTheme.typography.bodyMedium) }
                    if (event.previousValue != null && event.currentValue != null) Text("→", color = UmniahColors.TextSecondary)
                    event.currentValue?.let { Text(it, color = UmniahColors.TextSecondary, style = MaterialTheme.typography.bodyMedium) }
                }
            }
            Text(formatTime(event.timestampMs), color = UmniahColors.TextSecondary, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
fun MapScreen(contentPadding: PaddingValues, onPrivacy: () -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(contentPadding),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { SectionTitle("Experience Map", "Optional location-correlated network measurements.") }
        item {
            PremiumCard(highlighted = true, modifier = Modifier.fillMaxWidth()) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Icon(Icons.Outlined.Map, null, tint = UmniahColors.MagentaBright, modifier = Modifier.size(44.dp))
                    Text("Map provider integration point", style = MaterialTheme.typography.titleLarge)
                    Text("The production build intentionally contains no embedded third-party map API key. Connect the approved Umniah map provider at deployment; stored map points remain governed by Approximate/Precise Location consent.", color = UmniahColors.TextSecondary)
                    PrimaryAction("Review location privacy", onClick = onPrivacy)
                }
            }
        }
        item {
            PremiumCard(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Planned filters", style = MaterialTheme.typography.titleMedium)
                    Text("Technology • Signal • Speed • Latency • 5G • 4G • Wi-Fi", color = UmniahColors.TextSecondary)
                    Text("Point clustering is applied by the map adapter for large datasets.", color = UmniahColors.TextSecondary)
                }
            }
        }
    }
}

@Composable
fun MoreScreen(
    contentPadding: PaddingValues,
    onDetails: () -> Unit,
    onPrivacy: () -> Unit,
    onSettings: () -> Unit,
    onAssistant: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(contentPadding),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { SectionTitle("More", "Advanced tools stay out of the way until you need them.") }
        item { MoreItem(Icons.Outlined.NetworkCheck, "Network Details", "Serving cell, signal and connectivity", onDetails) }
        item { MoreItem(Icons.Outlined.AutoAwesome, "AI Network Analyst", "Ask questions using collected measurements", onAssistant) }
        item { MoreItem(Icons.Outlined.PrivacyTip, "Privacy Center", "Control telemetry and location permissions", onPrivacy) }
        item { MoreItem(Icons.Outlined.Settings, "Settings", "Measurement policy and app behavior", onSettings) }
    }
}

@Composable
private fun MoreItem(icon: ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    PremiumCard(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Icon(icon, null, tint = UmniahColors.MagentaBright)
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(subtitle, color = UmniahColors.TextSecondary, style = MaterialTheme.typography.bodyMedium)
            }
            Icon(Icons.Outlined.ChevronRight, null, tint = UmniahColors.TextSecondary)
        }
    }
}

@Composable
fun PrivacyScreen(onBack: () -> Unit, viewModel: PrivacyViewModel = hiltViewModel()) {
    val consents by viewModel.consents.collectAsState()
    val context = LocalContext.current
    var pendingPermissionConsent by remember { mutableStateOf<ConsentType?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        when (pendingPermissionConsent) {
            ConsentType.APPROXIMATE_LOCATION -> viewModel.set(ConsentType.APPROXIMATE_LOCATION, result[Manifest.permission.ACCESS_COARSE_LOCATION] == true || result[Manifest.permission.ACCESS_FINE_LOCATION] == true)
            ConsentType.PRECISE_LOCATION -> viewModel.set(ConsentType.PRECISE_LOCATION, result[Manifest.permission.ACCESS_FINE_LOCATION] == true)
            else -> Unit
        }
        pendingPermissionConsent = null
    }

    fun change(type: ConsentType, enable: Boolean) {
        if (!enable) {
            viewModel.set(type, false)
            if (type == ConsentType.APPROXIMATE_LOCATION) viewModel.set(ConsentType.PRECISE_LOCATION, false)
            return
        }
        when (type) {
            ConsentType.NETWORK_MEASUREMENTS -> {
                viewModel.set(type, true)
                if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                    launcher.launch(arrayOf(Manifest.permission.READ_PHONE_STATE))
                }
            }
            ConsentType.APPROXIMATE_LOCATION -> {
                pendingPermissionConsent = type
                launcher.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION))
            }
            ConsentType.PRECISE_LOCATION -> {
                pendingPermissionConsent = type
                launcher.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION))
            }
            else -> viewModel.set(type, true)
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { BackHeader("Privacy Center", onBack) }
        item {
            PremiumCard(highlighted = true, modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Outlined.PrivacyTip, null, tint = UmniahColors.MagentaBright)
                    Text("Your Network Insights", style = MaterialTheme.typography.headlineMedium)
                    Text("Simple controls for what this app may collect. Remote policy can reduce collection, but it cannot turn on a consent you disabled.", color = UmniahColors.TextSecondary)
                }
            }
        }
        item { ConsentToggle(consents, ConsentType.NETWORK_MEASUREMENTS, "Network measurements", "Connectivity, radio technology and Android-exposed network state", "Understand coverage and connection changes", ::change) }
        item { ConsentToggle(consents, ConsentType.DEVICE_INFORMATION, "Device information", "Model, Android version, battery, storage and capability context", "Separate network issues from device-related patterns", ::change) }
        item { ConsentToggle(consents, ConsentType.PERFORMANCE_MEASUREMENTS, "Performance measurements", "DNS, TCP/TLS/HTTP response and controlled throughput tests", "Measure the experience, not just signal", ::change) }
        item { ConsentToggle(consents, ConsentType.APPROXIMATE_LOCATION, "Approximate location", "A reduced-precision geohash when policy allows", "Correlate experience with broad areas", ::change) }
        item { ConsentToggle(consents, ConsentType.PRECISE_LOCATION, "Precise location", "Exact coordinates only when you explicitly enable it and Android grants Fine Location", "Pinpoint localized coverage patterns", ::change) }
        item { ConsentToggle(consents, ConsentType.BACKGROUND_MEASUREMENTS, "Background measurements", "Battery-aware snapshots scheduled by Android", "Build a longer-term experience history", ::change) }
        item { ConsentToggle(consents, ConsentType.DIAGNOSTIC_TESTS, "Diagnostic tests", "Short user-triggered network checks", "Explain likely problem categories from measured evidence", ::change) }
        item {
            PremiumCard(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("About Android location permission", style = MaterialTheme.typography.titleMedium)
                    Text("Android also gates detailed CellInfo behind location permission on many versions. If location permission is not granted, the app still works but serving/neighbor cell details may be limited. Location storage remains controlled separately by the toggles above.", color = UmniahColors.TextSecondary)
                }
            }
        }
    }
}

@Composable
private fun ConsentToggle(
    records: List<ConsentRecord>,
    type: ConsentType,
    title: String,
    what: String,
    why: String,
    onChange: (ConsentType, Boolean) -> Unit
) {
    val checked = records.firstOrNull { it.type == type }?.mode == ConsentMode.ENABLED
    PremiumCard(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text("What: $what", color = UmniahColors.TextSecondary, style = MaterialTheme.typography.bodyMedium)
                Text("Why: $why", color = UmniahColors.TextSecondary, style = MaterialTheme.typography.bodyMedium)
            }
            Switch(checked = checked, onCheckedChange = { onChange(type, it) })
        }
    }
}

@Composable
fun SettingsScreen(onBack: () -> Unit, viewModel: SettingsViewModel = hiltViewModel()) {
    val policy by viewModel.policy.collectAsState()
    LazyColumn(
        modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { BackHeader("Settings", onBack) }
        item { SectionTitle("Measurement policy", "Downloaded policy can reduce work but never override user consent.") }
        item {
            PremiumCard(modifier = Modifier.fillMaxWidth()) {
                Column {
                    DetailRow("Policy version", policy.version.toString())
                    DetailRow("Background interval", "${policy.samplingIntervalSeconds / 60} min target")
                    DetailRow("Battery threshold", "${policy.batteryThresholdPercent}%")
                    DetailRow("Location collection", if (policy.enableLocation) "Allowed by policy" else "Disabled by policy")
                    DetailRow("Speed tests", if (policy.enableSpeedTests) "Allowed by policy" else "Disabled by policy")
                    DetailRow("Daily active-test budget", "${policy.maxDailyTestBytes / 1024 / 1024} MB")
                }
            }
        }
        item {
            PremiumCard(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Efficiency", style = MaterialTheme.typography.titleMedium)
                    Text("Connectivity changes are event-driven. Ordinary background work is scheduled with WorkManager and active performance tests are not run continuously.", color = UmniahColors.TextSecondary)
                }
            }
        }
    }
}

@Composable
fun AssistantScreen(onBack: () -> Unit, viewModel: AssistantViewModel = hiltViewModel()) {
    val answer by viewModel.answer.collectAsState()
    var text by remember { mutableStateOf("") }
    val prompts = listOf("Why is my Internet slow?", "Is my signal good?", "Why did I switch from 5G?", "Wi-Fi or mobile?")
    LazyColumn(
        modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { BackHeader("AI Network Analyst", onBack) }
        item {
            PremiumCard(highlighted = true, modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Outlined.AutoAwesome, null, tint = UmniahColors.MagentaBright)
                    Text("Evidence first", style = MaterialTheme.typography.titleLarge)
                    Text("This baseline assistant answers from measurements already collected on this device. A production cloud LLM should be called only through the protected Umniah backend, never with an API key embedded in the app.", color = UmniahColors.TextSecondary)
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                prompts.chunked(2).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { prompt -> AssistChip(onClick = { text = prompt; viewModel.ask(prompt) }, label = { Text(prompt, maxLines = 1) }) }
                    }
                }
            }
        }
        item {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                label = { Text("Ask about your network") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { if (text.isNotBlank()) viewModel.ask(text) })
            )
        }
        item { PrimaryAction("Ask", onClick = { if (text.isNotBlank()) viewModel.ask(text) }, enabled = text.isNotBlank()) }
        answer?.let { value ->
            item {
                PremiumCard(modifier = Modifier.fillMaxWidth()) {
                    Text(value, color = UmniahColors.TextPrimary, style = MaterialTheme.typography.bodyLarge)
                }
            }
        }
    }
}

@Composable
private fun ExpandableDetails(title: String, initiallyExpanded: Boolean = false, content: @Composable () -> Unit) {
    var expanded by remember { mutableStateOf(initiallyExpanded) }
    PremiumCard(modifier = Modifier.fillMaxWidth()) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth().clickable { expanded = !expanded },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(title, style = MaterialTheme.typography.titleLarge)
                Icon(if (expanded) Icons.Outlined.ExpandLess else Icons.Outlined.ExpandMore, null, tint = UmniahColors.TextSecondary)
            }
            AnimatedVisibility(expanded) {
                Column(Modifier.padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) { content() }
            }
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = UmniahColors.TextSecondary, modifier = Modifier.weight(1f))
        Spacer(Modifier.width(12.dp))
        Text(value, color = UmniahColors.TextPrimary, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun BackHeader(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, "Back") }
        Text(title, style = MaterialTheme.typography.headlineMedium)
    }
}

private fun networkLabel(state: LiveNetworkState): String = when {
    state.transport == TransportType.WIFI -> "Wi-Fi"
    state.architecture5g.name == "NSA" || state.architecture5g.name == "PROBABLE_NSA" -> "5G NSA"
    state.technology == NetworkTechnology.NR -> "5G"
    state.technology == NetworkTechnology.LTE -> "4G LTE"
    state.technology == NetworkTechnology.WCDMA -> "3G"
    state.technology == NetworkTechnology.GSM -> "2G"
    else -> "Network"
}

private fun transportLabel(transport: TransportType): String = when (transport) {
    TransportType.CELLULAR -> "Mobile network"
    TransportType.WIFI -> "Wi-Fi"
    TransportType.ETHERNET -> "Ethernet"
    TransportType.VPN -> "VPN"
    TransportType.NONE -> "No active network"
    TransportType.OTHER -> "Other network"
}

private fun signalLabel(state: LiveNetworkState): String = when (state.signalLevel) {
    4 -> "Excellent"
    3 -> "Good"
    2 -> "Fair"
    1 -> "Weak"
    0 -> "Very weak"
    else -> "Unavailable"
}

private fun eventColor(type: EventType): Color = when (type) {
    EventType.INTERNET_LOST, EventType.SIGNAL_DEGRADED, EventType.HIGH_LATENCY, EventType.LOW_THROUGHPUT -> UmniahColors.Negative
    EventType.INTERNET_RECOVERED, EventType.SIGNAL_RECOVERED, EventType.FIVE_G_CONNECTED -> UmniahColors.Positive
    else -> UmniahColors.Info
}

private fun formatTime(epochMs: Long): String = DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(epochMs))

private fun formatMeasurement(value: Double, unit: String): String = when (unit) {
    "ms" -> "${value.toInt()} ms"
    "%" -> "${"%.1f".format(Locale.US, value)}%"
    "Mbps" -> "${"%.1f".format(Locale.US, value)} Mbps"
    else -> "${"%.2f".format(Locale.US, value)} $unit"
}

package com.umniah.networkinsights

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Map
import androidx.compose.material.icons.outlined.MoreHoriz
import androidx.compose.material.icons.outlined.Timeline
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.umniah.networkinsights.core.designsystem.UmniahColors

private data class BottomDestination(val route: String, val label: String, val icon: ImageVector)
private val bottomDestinations = listOf(
    BottomDestination("home", "Home", Icons.Outlined.Home),
    BottomDestination("timeline", "Timeline", Icons.Outlined.Timeline),
    BottomDestination("map", "Map", Icons.Outlined.Map),
    BottomDestination("more", "More", Icons.Outlined.MoreHoriz)
)

@Composable
fun UmniahApp() {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route

    Scaffold(
        containerColor = UmniahColors.Background,
        bottomBar = {
            if (route in bottomDestinations.map { it.route }) {
                NavigationBar(containerColor = UmniahColors.Surface) {
                    bottomDestinations.forEach { destination ->
                        NavigationBarItem(
                            selected = route == destination.route,
                            onClick = {
                                nav.navigate(destination.route) {
                                    popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(destination.icon, destination.label) },
                            label = { Text(destination.label) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(navController = nav, startDestination = "home") {
            composable("home") { HomeScreen(padding, onCheck = { nav.navigate("diagnostic") }, onDetails = { nav.navigate("details") }, onPrivacy = { nav.navigate("privacy") }) }
            composable("timeline") { TimelineScreen(padding) }
            composable("map") { MapScreen(padding, onPrivacy = { nav.navigate("privacy") }) }
            composable("more") { MoreScreen(padding, onDetails = { nav.navigate("details") }, onPrivacy = { nav.navigate("privacy") }, onSettings = { nav.navigate("settings") }, onAssistant = { nav.navigate("assistant") }) }
            composable("details") { DetailsScreen(onBack = { nav.popBackStack() }) }
            composable("diagnostic") { DiagnosticScreen(onBack = { nav.popBackStack() }, onPrivacy = { nav.navigate("privacy") }) }
            composable("privacy") { PrivacyScreen(onBack = { nav.popBackStack() }) }
            composable("settings") { SettingsScreen(onBack = { nav.popBackStack() }) }
            composable("assistant") { AssistantScreen(onBack = { nav.popBackStack() }) }
        }
    }
}

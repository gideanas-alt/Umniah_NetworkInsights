package com.umniah.networkinsights.core.designsystem

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.umniah.networkinsights.core.model.ExperienceGrade

private val cardShape = RoundedCornerShape(28.dp)

@Composable
fun PremiumCard(
    modifier: Modifier = Modifier,
    highlighted: Boolean = false,
    content: @Composable () -> Unit
) {
    val brush = if (highlighted) {
        Brush.linearGradient(listOf(Color(0xFF251018), Color(0xFF15151A), Color(0xFF111116)))
    } else {
        Brush.linearGradient(listOf(UmniahColors.SurfaceHigh, UmniahColors.Surface))
    }
    Box(
        modifier = modifier
            .clip(cardShape)
            .background(brush)
            .border(1.dp, if (highlighted) Color(0x55D60037) else UmniahColors.Divider, cardShape)
            .padding(20.dp)
    ) { content() }
}

@Composable
fun MetricTile(label: String, value: String, modifier: Modifier = Modifier, supporting: String? = null) {
    Column(modifier = modifier) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = UmniahColors.TextSecondary)
        Spacer(Modifier.height(6.dp))
        Text(value, style = MaterialTheme.typography.titleLarge, color = UmniahColors.TextPrimary)
        if (!supporting.isNullOrBlank()) {
            Spacer(Modifier.height(3.dp))
            Text(supporting, style = MaterialTheme.typography.bodyMedium, color = UmniahColors.TextSecondary)
        }
    }
}

@Composable
fun GradePill(grade: ExperienceGrade) {
    val color = when (grade) {
        ExperienceGrade.EXCELLENT -> UmniahColors.Positive
        ExperienceGrade.GOOD -> Color(0xFF9ADA8E)
        ExperienceGrade.FAIR -> UmniahColors.Warning
        ExperienceGrade.POOR -> UmniahColors.Negative
        ExperienceGrade.UNAVAILABLE -> UmniahColors.TextSecondary
    }
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(100.dp))
            .background(color.copy(alpha = 0.13f))
            .border(1.dp, color.copy(alpha = 0.45f), RoundedCornerShape(100.dp))
            .padding(horizontal = 12.dp, vertical = 7.dp)
    ) {
        Text(grade.name.lowercase().replaceFirstChar { it.uppercase() }, color = color, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
fun PrimaryAction(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.fillMaxWidth().height(54.dp),
        shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.buttonColors(containerColor = UmniahColors.Magenta, contentColor = Color.White)
    ) {
        Text(text, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
fun SectionTitle(title: String, subtitle: String? = null) {
    Column {
        Text(title, style = MaterialTheme.typography.titleLarge, color = UmniahColors.TextPrimary)
        if (!subtitle.isNullOrBlank()) {
            Spacer(Modifier.height(4.dp))
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = UmniahColors.TextSecondary)
        }
    }
}

@Composable
fun StatusDot(text: String, positive: Boolean) {
    val color = if (positive) UmniahColors.Positive else UmniahColors.Negative
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(Modifier.clip(RoundedCornerShape(100.dp)).background(color).padding(4.dp))
        Text(text, color = UmniahColors.TextSecondary, style = MaterialTheme.typography.bodyMedium)
    }
}

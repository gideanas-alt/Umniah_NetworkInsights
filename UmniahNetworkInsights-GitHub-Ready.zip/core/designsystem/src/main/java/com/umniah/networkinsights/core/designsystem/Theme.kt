package com.umniah.networkinsights.core.designsystem

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

object UmniahColors {
    val Magenta = Color(0xFFD60037)
    val MagentaBright = Color(0xFFFF315F)
    val Background = Color(0xFF09090B)
    val Surface = Color(0xFF131318)
    val SurfaceHigh = Color(0xFF1A1A20)
    val SurfaceHighest = Color(0xFF23232A)
    val TextPrimary = Color(0xFFF7F7F8)
    val TextSecondary = Color(0xFFA7A7B1)
    val Divider = Color(0xFF2A2A32)
    val Positive = Color(0xFF64D8A1)
    val Warning = Color(0xFFFFC768)
    val Negative = Color(0xFFFF6B74)
    val Info = Color(0xFF7FB7FF)
}

private val PremiumDarkScheme = darkColorScheme(
    primary = UmniahColors.Magenta,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF4D0013),
    onPrimaryContainer = Color(0xFFFFD9E0),
    secondary = UmniahColors.MagentaBright,
    background = UmniahColors.Background,
    onBackground = UmniahColors.TextPrimary,
    surface = UmniahColors.Surface,
    onSurface = UmniahColors.TextPrimary,
    surfaceVariant = UmniahColors.SurfaceHigh,
    onSurfaceVariant = UmniahColors.TextSecondary,
    outline = UmniahColors.Divider,
    error = UmniahColors.Negative
)

@Composable
fun UmniahPremiumDarkTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = PremiumDarkScheme,
        typography = MaterialTheme.typography.copy(
            displaySmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 38.sp, lineHeight = 42.sp),
            headlineLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 30.sp, lineHeight = 36.sp),
            headlineMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 24.sp, lineHeight = 30.sp),
            titleLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 20.sp, lineHeight = 26.sp),
            titleMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 22.sp),
            bodyLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 24.sp),
            bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 20.sp),
            labelLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 20.sp)
        ),
        content = content
    )
}

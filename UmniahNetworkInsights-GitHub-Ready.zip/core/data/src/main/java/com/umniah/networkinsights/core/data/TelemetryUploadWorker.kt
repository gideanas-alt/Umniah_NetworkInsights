package com.umniah.networkinsights.core.data

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.umniah.networkinsights.domain.InstallationRepository
import com.umniah.networkinsights.domain.TelemetryRepository
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import java.util.UUID
import java.util.concurrent.TimeUnit

@HiltWorker
class TelemetryUploadWorker @AssistedInject constructor(
    @Assisted appContext: Context,
    @Assisted params: WorkerParameters,
    private val repository: TelemetryRepository,
    private val installationRepository: InstallationRepository,
    private val api: TelemetryApi
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        if (!BackendDeploymentConfig.ENABLE_UPLOADS) return Result.success()
        val pending = repository.pendingPayloads(limit = 250)
        if (pending.isEmpty()) return Result.success()
        return runCatching {
            val response = api.uploadBatch(
                TelemetryBatchRequest(
                    batchId = UUID.randomUUID().toString(),
                    installationId = installationRepository.installationId(),
                    eventCount = pending.size,
                    payloads = pending.map { it.payload }
                )
            )
            if (response.accepted) {
                repository.markUploaded(pending.map { it.id })
                Result.success()
            } else {
                val delay = (response.retryAfterSeconds ?: 300L).coerceIn(60L, 86_400L)
                repository.markFailed(pending.map { it.id }, System.currentTimeMillis() + delay * 1_000L)
                Result.retry()
            }
        }.getOrElse {
            val backoffSeconds = (30L * (1L shl runAttemptCount.coerceIn(0, 8))).coerceAtMost(6L * 60L * 60L)
            repository.markFailed(pending.map { it.id }, System.currentTimeMillis() + backoffSeconds * 1_000L)
            Result.retry()
        }
    }
}

object SyncScheduler {
    private const val UNIQUE_WORK = "telemetry-upload"

    fun ensureScheduled(context: Context) {
        val request = PeriodicWorkRequestBuilder<TelemetryUploadWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            UNIQUE_WORK,
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }
}

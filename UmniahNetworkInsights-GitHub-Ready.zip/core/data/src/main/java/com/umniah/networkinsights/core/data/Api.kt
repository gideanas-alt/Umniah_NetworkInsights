package com.umniah.networkinsights.core.data

import javax.inject.Inject
import kotlinx.serialization.Serializable
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

@Serializable
data class TelemetryBatchRequest(
    val batchId: String,
    val installationId: String,
    val schemaVersion: Int = 1,
    val eventCount: Int,
    val payloads: List<String>
)

@Serializable
data class TelemetryBatchResponse(
    val accepted: Boolean,
    val acceptedEventIds: List<String> = emptyList(),
    val retryAfterSeconds: Long? = null,
    val configVersion: Long? = null
)

@Serializable
data class RemoteConfigResponse(
    val policyJson: String
)

interface TelemetryApi {
    @POST("api/v1/telemetry/batches")
    suspend fun uploadBatch(@Body body: TelemetryBatchRequest): TelemetryBatchResponse

    @GET("api/v1/config")
    suspend fun config(): RemoteConfigResponse
}

interface InstallationAuthTokenProvider {
    suspend fun bearerToken(): String?
}

class NoOpInstallationAuthTokenProvider @Inject constructor() : InstallationAuthTokenProvider {
    override suspend fun bearerToken(): String? = null
}

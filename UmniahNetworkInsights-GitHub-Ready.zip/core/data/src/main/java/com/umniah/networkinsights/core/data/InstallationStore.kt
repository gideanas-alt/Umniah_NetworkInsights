package com.umniah.networkinsights.core.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.umniah.networkinsights.domain.InstallationRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.first

private val Context.installationDataStore by preferencesDataStore(name = "installation")

@Singleton
class InstallationRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : InstallationRepository {
    private val idKey = stringPreferencesKey("installation_id")
    private val sequenceKey = longPreferencesKey("sequence")

    override suspend fun installationId(): String {
        val existing = context.installationDataStore.data.first()[idKey]
        if (existing != null) return existing
        val newId = UUID.randomUUID().toString()
        context.installationDataStore.edit { if (it[idKey] == null) it[idKey] = newId }
        return context.installationDataStore.data.first()[idKey] ?: newId
    }

    override suspend fun nextSequence(): Long {
        var result = 0L
        context.installationDataStore.edit { prefs ->
            result = (prefs[sequenceKey] ?: 0L) + 1L
            prefs[sequenceKey] = result
        }
        return result
    }
}

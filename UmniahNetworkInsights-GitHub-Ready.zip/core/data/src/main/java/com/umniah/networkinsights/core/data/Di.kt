package com.umniah.networkinsights.core.data

import android.content.Context
import androidx.room.Room
import com.umniah.networkinsights.domain.ConsentRepository
import com.umniah.networkinsights.domain.InstallationRepository
import com.umniah.networkinsights.domain.PolicyRepository
import com.umniah.networkinsights.domain.TelemetryRepository
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryBindings {
    @Binds abstract fun telemetry(impl: TelemetryRepositoryImpl): TelemetryRepository
    @Binds abstract fun consent(impl: ConsentRepositoryImpl): ConsentRepository
    @Binds abstract fun policy(impl: PolicyRepositoryImpl): PolicyRepository
    @Binds abstract fun installation(impl: InstallationRepositoryImpl): InstallationRepository
    @Binds abstract fun tokenProvider(impl: NoOpInstallationAuthTokenProvider): InstallationAuthTokenProvider
}

@Module
@InstallIn(SingletonComponent::class)
object DataModule {
    @Provides @Singleton
    fun json(): Json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
        explicitNulls = false
    }

    @Provides @Singleton
    fun database(@ApplicationContext context: Context): InsightsDatabase =
        Room.databaseBuilder(context, InsightsDatabase::class.java, "umniah_insights.db")
            .build()

    @Provides fun telemetryDao(db: InsightsDatabase) = db.telemetryDao()
    @Provides fun eventDao(db: InsightsDatabase) = db.networkEventDao()
    @Provides fun consentDao(db: InsightsDatabase) = db.consentDao()
    @Provides fun policyDao(db: InsightsDatabase) = db.policyDao()

    @Provides @Singleton
    fun okHttp(): OkHttpClient = OkHttpClient.Builder()
        .retryOnConnectionFailure(true)
        .build()

    @Provides @Singleton
    fun api(client: OkHttpClient, json: Json): TelemetryApi = Retrofit.Builder()
        // Replace with the production Umniah API gateway host during deployment.
        .baseUrl(BackendDeploymentConfig.API_BASE_URL)
        .client(client)
        .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
        .build()
        .create(TelemetryApi::class.java)
}

package com.umniah.networkinsights.core.data

/**
 * Deployment gate. Keep uploads disabled until the real Umniah API gateway, authentication and
 * certificate-rotation strategy are configured. This prevents a development build from exporting telemetry.
 */
object BackendDeploymentConfig {
    const val ENABLE_UPLOADS: Boolean = false
    const val API_BASE_URL: String = "https://telemetry.invalid/"
}

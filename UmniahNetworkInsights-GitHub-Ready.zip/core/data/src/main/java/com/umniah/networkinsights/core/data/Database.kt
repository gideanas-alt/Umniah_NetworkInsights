package com.umniah.networkinsights.core.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "telemetry_queue")
data class TelemetryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val eventId: String,
    val timestampMs: Long,
    val measurementType: String,
    val payloadJson: String,
    val attemptCount: Int = 0,
    val nextAttemptAtMs: Long = 0,
    val uploaded: Boolean = false
)

@Entity(tableName = "network_events")
data class NetworkEventEntity(
    @PrimaryKey val eventId: String,
    val timestampMs: Long,
    val type: String,
    val payloadJson: String
)

@Entity(tableName = "consent")
data class ConsentEntity(
    @PrimaryKey val type: String,
    val enabled: Boolean,
    val updatedAtMs: Long,
    val policyVersion: Int
)

@Entity(tableName = "remote_policy")
data class PolicyEntity(
    @PrimaryKey val singletonId: Int = 1,
    val version: Long,
    val payloadJson: String,
    val updatedAtMs: Long
)

@Dao
interface TelemetryDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: TelemetryEntity): Long

    @Query("SELECT * FROM telemetry_queue WHERE uploaded = 0 AND nextAttemptAtMs <= :nowMs ORDER BY id LIMIT :limit")
    suspend fun pending(nowMs: Long, limit: Int): List<TelemetryEntity>

    @Query("UPDATE telemetry_queue SET uploaded = 1 WHERE id IN (:ids)")
    suspend fun markUploaded(ids: List<Long>)

    @Query("UPDATE telemetry_queue SET attemptCount = attemptCount + 1, nextAttemptAtMs = :retryAtMs WHERE id IN (:ids)")
    suspend fun markFailed(ids: List<Long>, retryAtMs: Long)

    @Query("DELETE FROM telemetry_queue WHERE uploaded = 1 AND timestampMs < :beforeMs")
    suspend fun purgeUploaded(beforeMs: Long)
}

@Dao
interface NetworkEventDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(events: List<NetworkEventEntity>)

    @Query("SELECT * FROM network_events ORDER BY timestampMs DESC LIMIT :limit")
    fun observeRecent(limit: Int): Flow<List<NetworkEventEntity>>

    @Query("DELETE FROM network_events WHERE timestampMs < :beforeMs")
    suspend fun purge(beforeMs: Long)
}

@Dao
interface ConsentDao {
    @Query("SELECT * FROM consent")
    fun observeAll(): Flow<List<ConsentEntity>>

    @Query("SELECT * FROM consent WHERE type = :type LIMIT 1")
    suspend fun get(type: String): ConsentEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: ConsentEntity)
}

@Dao
interface PolicyDao {
    @Query("SELECT * FROM remote_policy WHERE singletonId = 1 LIMIT 1")
    fun observe(): Flow<PolicyEntity?>

    @Query("SELECT * FROM remote_policy WHERE singletonId = 1 LIMIT 1")
    suspend fun get(): PolicyEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: PolicyEntity)
}

@Database(
    entities = [TelemetryEntity::class, NetworkEventEntity::class, ConsentEntity::class, PolicyEntity::class],
    version = 1,
    exportSchema = true
)
abstract class InsightsDatabase : RoomDatabase() {
    abstract fun telemetryDao(): TelemetryDao
    abstract fun networkEventDao(): NetworkEventDao
    abstract fun consentDao(): ConsentDao
    abstract fun policyDao(): PolicyDao
}

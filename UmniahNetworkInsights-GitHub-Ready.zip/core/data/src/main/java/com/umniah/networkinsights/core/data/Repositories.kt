package com.umniah.networkinsights.core.data

import com.umniah.networkinsights.core.model.ConsentMode
import com.umniah.networkinsights.core.model.ConsentRecord
import com.umniah.networkinsights.core.model.ConsentType
import com.umniah.networkinsights.core.model.NetworkEvent
import com.umniah.networkinsights.core.model.RemoteMeasurementPolicy
import com.umniah.networkinsights.core.model.TelemetryEnvelope
import com.umniah.networkinsights.domain.ConsentRepository
import com.umniah.networkinsights.domain.PolicyRepository
import com.umniah.networkinsights.domain.StoredTelemetryPayload
import com.umniah.networkinsights.domain.TelemetryRepository
import android.util.Base64
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.json.Json

@Singleton
class TelemetryRepositoryImpl @Inject constructor(
    private val telemetryDao: TelemetryDao,
    private val eventDao: NetworkEventDao,
    private val json: Json,
    private val crypto: KeyStoreCrypto
) : TelemetryRepository {
    override suspend fun enqueue(envelope: TelemetryEnvelope) {
        telemetryDao.insert(
            TelemetryEntity(
                eventId = envelope.eventId,
                timestampMs = envelope.timestampMs,
                measurementType = envelope.measurementType.name,
                payloadJson = encrypt(json.encodeToString(TelemetryEnvelope.serializer(), envelope))
            )
        )
        if (envelope.events.isNotEmpty()) {
            eventDao.insertAll(envelope.events.map {
                NetworkEventEntity(it.eventId, it.timestampMs, it.type.name, encrypt(json.encodeToString(NetworkEvent.serializer(), it)))
            })
        }
    }

    override fun observeRecentEvents(limit: Int): Flow<List<NetworkEvent>> =
        eventDao.observeRecent(limit).map { rows -> rows.mapNotNull { runCatching { json.decodeFromString(NetworkEvent.serializer(), decrypt(it.payloadJson)) }.getOrNull() } }

    override suspend fun pendingPayloads(limit: Int): List<StoredTelemetryPayload> =
        telemetryDao.pending(System.currentTimeMillis(), limit).map { StoredTelemetryPayload(it.id, it.eventId, decrypt(it.payloadJson), it.attemptCount) }

    override suspend fun markUploaded(ids: List<Long>) {
        if (ids.isNotEmpty()) telemetryDao.markUploaded(ids)
    }

    override suspend fun markFailed(ids: List<Long>, retryAtMs: Long) {
        if (ids.isNotEmpty()) telemetryDao.markFailed(ids, retryAtMs)
    }

    private fun encrypt(value: String): String = Base64.encodeToString(crypto.encrypt(value.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
    private fun decrypt(value: String): String = String(crypto.decrypt(Base64.decode(value, Base64.NO_WRAP)), Charsets.UTF_8)
}

@Singleton
class ConsentRepositoryImpl @Inject constructor(private val dao: ConsentDao) : ConsentRepository {
    override fun observeAll(): Flow<List<ConsentRecord>> = dao.observeAll().map { rows ->
        ConsentType.entries.map { type ->
            val row = rows.firstOrNull { it.type == type.name }
            ConsentRecord(
                type = type,
                mode = if (row?.enabled == true) ConsentMode.ENABLED else ConsentMode.DISABLED,
                updatedAtMs = row?.updatedAtMs ?: 0,
                policyVersion = row?.policyVersion ?: 1
            )
        }
    }

    override suspend fun isEnabled(type: ConsentType): Boolean = dao.get(type.name)?.enabled == true

    override suspend fun set(type: ConsentType, enabled: Boolean) {
        dao.upsert(ConsentEntity(type.name, enabled, System.currentTimeMillis(), 1))
    }
}

@Singleton
class PolicyRepositoryImpl @Inject constructor(private val dao: PolicyDao, private val json: Json) : PolicyRepository {
    private val defaultPolicy = RemoteMeasurementPolicy()

    override fun observePolicy(): Flow<RemoteMeasurementPolicy> = dao.observe().map { entity ->
        entity?.let { runCatching { json.decodeFromString(RemoteMeasurementPolicy.serializer(), it.payloadJson) }.getOrNull() } ?: defaultPolicy
    }

    override suspend fun current(): RemoteMeasurementPolicy = dao.get()?.let {
        runCatching { json.decodeFromString(RemoteMeasurementPolicy.serializer(), it.payloadJson) }.getOrNull()
    } ?: defaultPolicy

    override suspend fun update(policy: RemoteMeasurementPolicy) {
        dao.upsert(PolicyEntity(version = policy.version, payloadJson = json.encodeToString(RemoteMeasurementPolicy.serializer(), policy), updatedAtMs = System.currentTimeMillis()))
    }
}

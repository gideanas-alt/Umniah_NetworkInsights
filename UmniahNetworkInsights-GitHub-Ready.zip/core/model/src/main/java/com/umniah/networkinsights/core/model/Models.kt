package com.umniah.networkinsights.core.model

import kotlinx.serialization.Serializable

@Serializable
enum class NetworkTechnology { UNKNOWN, GSM, WCDMA, LTE, NR, WIFI, ETHERNET }

@Serializable
enum class FiveGArchitecture { NOT_5G, SA, NSA, PROBABLE_SA, PROBABLE_NSA, UNKNOWN }

@Serializable
enum class Availability { AVAILABLE, UNAVAILABLE, UNSUPPORTED_API, PERMISSION_MISSING, OEM_REDACTED, STALE, THROTTLED, PARTIAL }

@Serializable
enum class CollectionTrigger { PERIODIC, CHANGE, USER, DIAGNOSTIC, RECOVERY }

@Serializable
enum class MeasurementType { DEVICE, SUBSCRIPTION, RADIO, CELL, CONNECTIVITY, WIFI, LOCATION, PERFORMANCE, EVENT, DIAGNOSTIC }

@Serializable
enum class TransportType { NONE, CELLULAR, WIFI, ETHERNET, VPN, OTHER }

@Serializable
enum class EventType {
    TECHNOLOGY_CHANGED,
    CELL_CHANGED,
    FIVE_G_CONNECTED,
    FIVE_G_FALLBACK,
    WIFI_CONNECTED,
    WIFI_DISCONNECTED,
    INTERNET_LOST,
    INTERNET_RECOVERED,
    SIGNAL_DEGRADED,
    SIGNAL_RECOVERED,
    HIGH_LATENCY,
    LOW_THROUGHPUT,
    ROAMING_STARTED,
    ROAMING_ENDED
}

@Serializable
enum class MobilityState { UNKNOWN, STATIONARY, WALKING, DRIVING, HIGH_SPEED }

@Serializable
enum class ExperienceGrade { EXCELLENT, GOOD, FAIR, POOR, UNAVAILABLE }

@Serializable
enum class DiagnosticClassification { RADIO, DEVICE, WIFI, INTERNET, DNS, NETWORK_PERFORMANCE, NO_PROBLEM, UNKNOWN }

@Serializable
enum class ConsentType { NETWORK_MEASUREMENTS, DEVICE_INFORMATION, PERFORMANCE_MEASUREMENTS, APPROXIMATE_LOCATION, PRECISE_LOCATION, BACKGROUND_MEASUREMENTS, DIAGNOSTIC_TESTS }

@Serializable
enum class ConsentMode { ENABLED, DISABLED }

@Serializable
data class MeasurementQuality(
    val availability: Availability = Availability.AVAILABLE,
    val source: String,
    val confidence: Double = 1.0,
    val ageMs: Long? = null,
    val accuracy: Double? = null,
    val permissionState: String? = null,
    val flags: List<String> = emptyList()
)

@Serializable
data class DeviceSnapshot(
    val timestampMs: Long,
    val manufacturer: String,
    val model: String,
    val device: String,
    val androidVersion: String,
    val sdkInt: Int,
    val cpuAbis: List<String>,
    val memoryClassMb: Int?,
    val totalRamMb: Long?,
    val availableStorageMb: Long?,
    val batteryPercent: Int?,
    val charging: Boolean?,
    val batteryTemperatureC: Double?,
    val thermalStatus: Int?,
    val uptimeMs: Long,
    val appVersion: String,
    val quality: MeasurementQuality
)

@Serializable
data class SubscriptionSnapshot(
    val timestampMs: Long,
    val subscriptionId: Int,
    val slotIndex: Int,
    val carrierId: Int?,
    val carrierName: String?,
    val mcc: String?,
    val mnc: String?,
    val roaming: Boolean,
    val isDefaultData: Boolean,
    val quality: MeasurementQuality
)

@Serializable
data class CellMeasurement(
    val timestampMs: Long,
    val subscriptionId: Int?,
    val registered: Boolean,
    val technology: NetworkTechnology,
    val mcc: String?,
    val mnc: String?,
    val cellId: Long?,
    val tac: Int?,
    val pci: Int?,
    val band: Int?,
    val channel: Int?,
    val rsrpDbm: Int?,
    val rsrqDb: Int?,
    val sinrDb: Int?,
    val rssiDbm: Int?,
    val timingAdvance: Int?,
    val quality: MeasurementQuality
)

@Serializable
data class RadioSnapshot(
    val timestampMs: Long,
    val subscriptionId: Int?,
    val technology: NetworkTechnology,
    val dataConnected: Boolean,
    val roaming: Boolean,
    val operatorName: String?,
    val signalLevel: Int?,
    val architecture5g: FiveGArchitecture,
    val architectureConfidence: Double,
    val displayOverride: String?,
    val cells: List<CellMeasurement>,
    val quality: MeasurementQuality
)


@Serializable
data class ImsSnapshot(
    val timestampMs: Long,
    val subscriptionId: Int?,
    val carrierPrivileges: Boolean,
    val registered: Boolean?,
    val registrationTransport: String?,
    val voiceCapabilityAvailable: Boolean?,
    val volteAvailable: Boolean?,
    val vowifiAvailable: Boolean?,
    val quality: MeasurementQuality
)

@Serializable
data class ConnectivitySnapshot(
    val timestampMs: Long,
    val transport: TransportType,
    val validated: Boolean,
    val captivePortal: Boolean,
    val metered: Boolean,
    val downstreamKbpsEstimate: Int?,
    val upstreamKbpsEstimate: Int?,
    val quality: MeasurementQuality
)

@Serializable
data class WifiSnapshot(
    val timestampMs: Long,
    val connected: Boolean,
    val frequencyMhz: Int?,
    val band: String?,
    val rssiDbm: Int?,
    val linkSpeedMbps: Int?,
    val rxLinkSpeedMbps: Int?,
    val txLinkSpeedMbps: Int?,
    val wifiStandard: String?,
    val networkValidated: Boolean,
    val quality: MeasurementQuality
)

@Serializable
data class LocationMeasurement(
    val timestampMs: Long,
    val latitude: Double?,
    val longitude: Double?,
    val geohash: String?,
    val accuracyM: Float?,
    val altitudeM: Double?,
    val speedMps: Float?,
    val bearingDeg: Float?,
    val source: String?,
    val privacyLevel: String,
    val quality: MeasurementQuality
)

@Serializable
data class PerformanceMeasurement(
    val timestampMs: Long,
    val metric: String,
    val value: Double?,
    val unit: String,
    val durationMs: Long,
    val endpoint: String?,
    val success: Boolean,
    val quality: MeasurementQuality
)

@Serializable
data class NetworkEvent(
    val eventId: String,
    val timestampMs: Long,
    val type: EventType,
    val message: String,
    val severity: Int,
    val confidence: Double,
    val previousValue: String? = null,
    val currentValue: String? = null
)

@Serializable
data class TelemetryEnvelope(
    val schemaVersion: Int = 1,
    val eventId: String,
    val installationId: String,
    val sequenceNumber: Long,
    val timestampMs: Long,
    val elapsedRealtimeMs: Long,
    val measurementType: MeasurementType,
    val trigger: CollectionTrigger,
    val device: DeviceSnapshot? = null,
    val subscriptions: List<SubscriptionSnapshot> = emptyList(),
    val radio: RadioSnapshot? = null,
    val connectivity: ConnectivitySnapshot? = null,
    val wifi: WifiSnapshot? = null,
    val ims: ImsSnapshot? = null,
    val location: LocationMeasurement? = null,
    val mobilityState: MobilityState = MobilityState.UNKNOWN,
    val performance: List<PerformanceMeasurement> = emptyList(),
    val events: List<NetworkEvent> = emptyList(),
    val consentVersion: Int = 1,
    val policyVersion: Long = 1,
    val quality: MeasurementQuality
)

@Serializable
data class LiveNetworkState(
    val collectedAtMs: Long = 0,
    val technology: NetworkTechnology = NetworkTechnology.UNKNOWN,
    val architecture5g: FiveGArchitecture = FiveGArchitecture.UNKNOWN,
    val operatorName: String? = null,
    val connected: Boolean = false,
    val internetValidated: Boolean = false,
    val transport: TransportType = TransportType.NONE,
    val signalLevel: Int? = null,
    val rsrpDbm: Int? = null,
    val rsrqDb: Int? = null,
    val sinrDb: Int? = null,
    val cell: CellMeasurement? = null,
    val latencyMs: Double? = null,
    val downloadMbps: Double? = null,
    val uploadMbps: Double? = null,
    val imsRegistered: Boolean? = null,
    val imsTransport: String? = null,
    val volteAvailable: Boolean? = null,
    val vowifiAvailable: Boolean? = null,
    val experience: ExperienceSummary = ExperienceSummary.unavailable(),
    val lastEvents: List<NetworkEvent> = emptyList()
)

@Serializable
data class ExperienceSummary(
    val grade: ExperienceGrade,
    val score: Int?,
    val signalScore: Int?,
    val availabilityScore: Int?,
    val responsivenessScore: Int?,
    val throughputScore: Int?,
    val stabilityScore: Int?,
    val explanation: String
) {
    companion object {
        fun unavailable() = ExperienceSummary(
            grade = ExperienceGrade.UNAVAILABLE,
            score = null,
            signalScore = null,
            availabilityScore = null,
            responsivenessScore = null,
            throughputScore = null,
            stabilityScore = null,
            explanation = "Run a network check to build an experience score."
        )
    }
}

@Serializable
data class DiagnosticResult(
    val classification: DiagnosticClassification,
    val confidence: Double,
    val title: String,
    val userMessage: String,
    val technicalExplanation: String,
    val evidence: List<String>,
    val recommendation: String?
)

@Serializable
data class ConsentRecord(
    val type: ConsentType,
    val mode: ConsentMode,
    val updatedAtMs: Long,
    val policyVersion: Int
)

@Serializable
data class RemoteMeasurementPolicy(
    val version: Long = 1,
    val samplingIntervalSeconds: Long = 900,
    val degradedSamplingIntervalSeconds: Long = 60,
    val enableLocation: Boolean = false,
    val enableSpeedTests: Boolean = false,
    val batteryThresholdPercent: Int = 30,
    val wifiMeasurements: Boolean = true,
    val cellMeasurements: Boolean = true,
    val diagnostics: Boolean = true,
    val maxDailyTestBytes: Long = 25L * 1024L * 1024L,
    val latencyHost: String = "www.umniah.com",
    val httpProbeUrl: String = "https://www.umniah.com/",
    val downloadProbeUrl: String? = null,
    val uploadProbeUrl: String? = null
)

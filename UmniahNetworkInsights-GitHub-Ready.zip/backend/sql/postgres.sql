CREATE TABLE installations (
  installation_id uuid PRIMARY KEY,
  created_at timestamptz NOT NULL DEFAULT now(),
  last_seen_at timestamptz NOT NULL DEFAULT now(),
  app_version text NOT NULL,
  os_version text NOT NULL,
  credential_version integer NOT NULL DEFAULT 1,
  status text NOT NULL DEFAULT 'ACTIVE'
);

CREATE TABLE consent_audit (
  id bigserial PRIMARY KEY,
  installation_id uuid NOT NULL REFERENCES installations(installation_id),
  consent_type text NOT NULL,
  enabled boolean NOT NULL,
  policy_version integer NOT NULL,
  changed_at timestamptz NOT NULL,
  received_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX consent_audit_installation_time_idx ON consent_audit(installation_id, changed_at DESC);

CREATE TABLE measurement_policy (
  version bigint PRIMARY KEY,
  valid_from timestamptz NOT NULL,
  valid_until timestamptz,
  payload jsonb NOT NULL,
  signature bytea,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE feature_flags (
  key text PRIMARY KEY,
  enabled boolean NOT NULL,
  configuration jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_at timestamptz NOT NULL DEFAULT now()
);

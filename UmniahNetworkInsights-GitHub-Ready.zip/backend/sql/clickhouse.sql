CREATE TABLE IF NOT EXISTS telemetry_measurements (
  event_id UUID,
  installation_id UUID,
  sequence_number UInt64,
  timestamp DateTime64(3, 'UTC'),
  measurement_type LowCardinality(String),
  trigger LowCardinality(String),
  operator_name Nullable(String),
  mcc Nullable(String),
  mnc Nullable(String),
  technology LowCardinality(String),
  five_g_architecture LowCardinality(Nullable(String)),
  cell_id Nullable(UInt64),
  tac Nullable(UInt32),
  pci Nullable(UInt16),
  band Nullable(UInt16),
  channel Nullable(UInt32),
  rsrp_dbm Nullable(Int16),
  rsrq_db Nullable(Int16),
  sinr_db Nullable(Int16),
  transport LowCardinality(Nullable(String)),
  internet_validated Nullable(Bool),
  geohash Nullable(String),
  location_accuracy_m Nullable(Float32),
  latency_ms Nullable(Float64),
  download_mbps Nullable(Float64),
  upload_mbps Nullable(Float64),
  quality_availability LowCardinality(String),
  quality_confidence Float32,
  app_version Nullable(String),
  os_version Nullable(String),
  device_manufacturer Nullable(String),
  device_model Nullable(String),
  policy_version UInt64,
  ingested_at DateTime64(3, 'UTC') DEFAULT now64(3)
)
ENGINE = MergeTree
PARTITION BY toYYYYMM(timestamp)
ORDER BY (toDate(timestamp), operator_name, technology, installation_id, timestamp, event_id)
TTL timestamp + INTERVAL 395 DAY;

CREATE TABLE IF NOT EXISTS network_events (
  event_id UUID,
  installation_id UUID,
  timestamp DateTime64(3, 'UTC'),
  event_type LowCardinality(String),
  severity UInt8,
  confidence Float32,
  technology LowCardinality(Nullable(String)),
  cell_id Nullable(UInt64),
  geohash Nullable(String),
  payload String,
  ingested_at DateTime64(3, 'UTC') DEFAULT now64(3)
)
ENGINE = MergeTree
PARTITION BY toYYYYMM(timestamp)
ORDER BY (toDate(timestamp), event_type, installation_id, timestamp, event_id)
TTL timestamp + INTERVAL 395 DAY;

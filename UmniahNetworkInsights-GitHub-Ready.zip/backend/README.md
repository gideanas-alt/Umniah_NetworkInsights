# Backend implementation contract

The Android client intentionally ships with telemetry uploads **disabled**. The deployment team must provide the real API gateway, installation authentication, retention policy, and certificate rotation plan before changing `BackendDeploymentConfig.ENABLE_UPLOADS`.

Recommended flow:

1. API Gateway terminates TLS, enforces rate/size limits and validates installation credentials.
2. Ingestion validates JSON schema/version, checks sequence and event IDs, deduplicates, then acknowledges only persisted events.
3. An event bus separates ingestion from enrichment.
4. Enrichment maps cell/site metadata, applies data-quality checks, and writes flattened time-series rows to ClickHouse while optionally retaining governed raw batches in object storage.
5. PostgreSQL owns installation state, consent audit, measurement policy and feature flags.
6. AI analysis executes server-side using a bounded evidence bundle. Never embed model/API credentials in the Android package.

The `openapi.yaml` and SQL files are deployment contracts, not a claim that production infrastructure has already been provisioned.
